"""Pegboard standards, mount layout, and printable mounting geometry.

The bin-side receiver is deliberately standard-neutral.  Only the board-side
adapter and board-grid rules vary by standard.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any

import numpy as np
import trimesh

from organizer_geometry import difference, union


@dataclass(frozen=True)
class PegboardStandard:
    id: str
    name: str
    pitch_x_mm: float
    pitch_y_mm: float
    opening_width_mm: float
    opening_height_mm: float
    opening_shape: str
    stagger_x_mm: float
    adapter_strategy: str
    board_holes_per_adapter: int
    first_seat_row: int
    seat_row_stride: int


PEGBOARD_STANDARDS: dict[str, PegboardStandard] = {
    "standard": PegboardStandard(
        "standard", "Standard Pegboard", 25.4, 25.4, 6.35, 6.35,
        "round", 0.0, "straight_and_hooked_pegs", 2, 1, 2,
    ),
    "skadis": PegboardStandard(
        "skadis", "IKEA SKÅDIS", 40.0, 20.0, 5.0, 15.0,
        "rounded_slot", 20.0, "skadis_slots", 1, 1, 1,
    ),
}

PEGBOARD_SIZE_MODES = ("physical", "holes")
PEGBOARD_MAX_CLEATS_X = 5
PEGBOARD_MAX_CLEATS_Y = 3
PEGBOARD_DEFAULT_DEPTH_MM = 350.0
PEGBOARD_RECEIVER_WIDTH = 14.0
PEGBOARD_RECEIVER_HEIGHT = 35.4
PEGBOARD_PROJECTION = 5.5
PEGBOARD_RIB_WIDTH = 2.0
PEGBOARD_MAX_UNSUPPORTED_GAP = 40.0
PEGBOARD_EDGE_INSET = 2.0
PEGBOARD_AUTO_SUPPORT_X = 72.0
PEGBOARD_AUTO_SUPPORT_Y = 64.0
PEGBOARD_CLEAT_BELOW_SEAT = 28.4
PEGBOARD_RECEIVER_ABOVE_SEAT = 7.0
# Positive retention: a short catch on the bin-side (low) end of the cleat
# slope.  The receiver's notch drops over it when the bin is lowered on, and
# its board-side wall then stops the bin travelling down-and-out along the
# slope.  Lifting the bin ~1 mm (the normal removal motion) clears it.
PEGBOARD_LATCH_DEPTH = 1.2          # catch length along the projection
PEGBOARD_LATCH_ABOVE_CENTER = 0.2   # catch top, above the cleat centre line
PEGBOARD_LATCH_CLEARANCE = 0.4      # receiver notch play around the catch
PEGBOARD_LATCH_WIDTH = 10.0         # same as the cleat body


@dataclass(frozen=True)
class PegboardMountSpec:
    enabled: bool = False
    standard: str = "standard"
    cleat_x: str | int = "auto"
    cleat_y: str | int = "auto"


def pegboard_catalog() -> dict[str, Any]:
    return {
        "standards": [
            {
                "id": one.id,
                "name": one.name,
                "pitch_x_mm": one.pitch_x_mm,
                "pitch_y_mm": one.pitch_y_mm,
                "opening_width_mm": one.opening_width_mm,
                "opening_height_mm": one.opening_height_mm,
                "opening_shape": one.opening_shape,
                "stagger_x_mm": one.stagger_x_mm,
                "adapter_strategy": one.adapter_strategy,
                "board_holes_per_adapter": one.board_holes_per_adapter,
                "first_seat_row": one.first_seat_row,
                "seat_row_stride": one.seat_row_stride,
                "minimum_widths_mm": [minimum_cleat_dimension(one, "x", count)
                                      for count in range(1, PEGBOARD_MAX_CLEATS_X + 1)],
                "minimum_heights_mm": [minimum_cleat_dimension(one, "y", count)
                                       for count in range(1, PEGBOARD_MAX_CLEATS_Y + 1)],
            }
            for one in PEGBOARD_STANDARDS.values()
        ],
        "size_modes": list(PEGBOARD_SIZE_MODES),
        "cleat_x": {"min": 1, "max": PEGBOARD_MAX_CLEATS_X},
        "cleat_y": {"min": 1, "max": PEGBOARD_MAX_CLEATS_Y},
        "receiver": {
            "width_mm": PEGBOARD_RECEIVER_WIDTH,
            "height_mm": PEGBOARD_RECEIVER_HEIGHT,
            "projection_mm": PEGBOARD_PROJECTION,
            "edge_inset_mm": PEGBOARD_EDGE_INSET,
            "max_unsupported_gap_mm": PEGBOARD_MAX_UNSUPPORTED_GAP,
        },
    }


def pegboard_standard(value: Any) -> PegboardStandard:
    key = str(value or "standard").strip().lower()
    try:
        return PEGBOARD_STANDARDS[key]
    except KeyError:
        raise ValueError("pegboard standard must be standard or skadis") from None


def minimum_cleat_dimension(standard: PegboardStandard, axis: str, count: int) -> float:
    """Smallest dimension that admits the requested grid-aligned count."""
    if axis == "y":
        center = (standard.first_seat_row + 0.5
                  + (count - 1) * standard.seat_row_stride) * standard.pitch_y_mm
        return round(center + PEGBOARD_EDGE_INSET + PEGBOARD_RECEIVER_ABOVE_SEAT, 6)
    first_center = standard.pitch_x_mm / 2.0 + (
        standard.stagger_x_mm if standard.first_seat_row % 2 else 0.0
    )
    return round(first_center + (count - 1) * standard.pitch_x_mm
                 + PEGBOARD_EDGE_INSET + PEGBOARD_RECEIVER_WIDTH / 2.0, 6)


def _positive(value: Any, name: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"pegboard {name} must be a number") from None
    if not math.isfinite(number) or number <= 0:
        raise ValueError(f"pegboard {name} must be positive")
    return number


def _whole(value: Any, name: str) -> int:
    number = _positive(value, name)
    if not math.isclose(number, round(number), abs_tol=1e-9):
        raise ValueError(f"pegboard {name} must be a whole number")
    return int(round(number))


def resolve_pegboard_size(
    standard_id: Any,
    size_mode: Any,
    *,
    width_mm: Any = None,
    height_mm: Any = None,
    holes_x: Any = None,
    holes_y: Any = None,
) -> dict[str, Any]:
    standard = pegboard_standard(standard_id)
    mode = str(size_mode or "physical").strip().lower()
    if mode not in PEGBOARD_SIZE_MODES:
        raise ValueError("pegboard size mode must be physical or holes")
    if mode == "holes":
        count_x = _whole(holes_x, "holes across")
        count_y = _whole(holes_y, "holes high")
        width = count_x * standard.pitch_x_mm
        height = count_y * standard.pitch_y_mm
        residual_x = residual_y = 0.0
    else:
        width = _positive(width_mm, "width")
        height = _positive(height_mm, "height")
        count_x = int(math.floor(width / standard.pitch_x_mm + 1e-9))
        count_y = int(math.floor(height / standard.pitch_y_mm + 1e-9))
        if count_x < 1 or count_y < 1:
            raise ValueError(
                f"{standard.name} needs at least {standard.pitch_x_mm:g} mm width "
                f"and {standard.pitch_y_mm:g} mm height"
            )
        residual_x = width - count_x * standard.pitch_x_mm
        residual_y = height - count_y * standard.pitch_y_mm
    if count_x > 500 or count_y > 500:
        raise ValueError("pegboard hole counts cannot exceed 500 per axis")
    return {
        "standard": standard.id,
        "standard_name": standard.name,
        "size_mode": mode,
        "width_mm": round(width, 6),
        "height_mm": round(height, 6),
        "holes_x": count_x,
        "holes_y": count_y,
        "usable_width_mm": round(count_x * standard.pitch_x_mm, 6),
        "usable_height_mm": round(count_y * standard.pitch_y_mm, 6),
        "residual_x_mm": round(residual_x, 6),
        "residual_y_mm": round(residual_y, 6),
        "border_x_mm": round(residual_x / 2.0, 6),
        "border_y_mm": round(residual_y / 2.0, 6),
    }


def normalise_pegboard_space(raw: dict[str, Any]) -> dict[str, Any]:
    resolved = resolve_pegboard_size(
        raw.get("pegboard_standard", raw.get("standard", "standard")),
        raw.get("pegboard_size_mode", raw.get("size_mode", "physical")),
        width_mm=raw.get("x", raw.get("width_mm")),
        height_mm=raw.get("y", raw.get("height_mm")),
        holes_x=raw.get("pegboard_holes_x", raw.get("holes_x")),
        holes_y=raw.get("pegboard_holes_y", raw.get("holes_y")),
    )
    return {
        "x": resolved["width_mm"],
        "y": resolved["height_mm"],
        "z": PEGBOARD_DEFAULT_DEPTH_MM,
        "pegboard_standard": resolved["standard"],
        "pegboard_thickness_mm": _positive(raw.get("pegboard_thickness_mm", 3.2), "board thickness"),
        "pegboard_size_mode": resolved["size_mode"],
        "pegboard_holes_x": resolved["holes_x"],
        "pegboard_holes_y": resolved["holes_y"],
        "pegboard_usable_x": resolved["usable_width_mm"],
        "pegboard_usable_y": resolved["usable_height_mm"],
        "pegboard_residual_x": resolved["residual_x_mm"],
        "pegboard_residual_y": resolved["residual_y_mm"],
    }


def _count(value: Any, maximum: int, axis: str) -> str | int:
    if str(value or "auto").strip().lower() == "auto":
        return "auto"
    try:
        count = int(value)
    except (TypeError, ValueError):
        raise ValueError(f"Cleat Count {axis} must be Auto or 1–{maximum}") from None
    if count < 1 or count > maximum:
        raise ValueError(f"Cleat Count {axis} must be Auto or 1–{maximum}")
    return count


def normalise_mount_spec(raw: Any) -> PegboardMountSpec:
    if isinstance(raw, PegboardMountSpec):
        return raw
    if not isinstance(raw, dict) or not bool(raw.get("enabled", False)):
        return PegboardMountSpec()
    return PegboardMountSpec(
        enabled=True,
        standard=pegboard_standard(raw.get("standard")).id,
        cleat_x=_count(raw.get("cleat_x", "auto"), PEGBOARD_MAX_CLEATS_X, "X"),
        cleat_y=_count(raw.get("cleat_y", "auto"), PEGBOARD_MAX_CLEATS_Y, "Y"),
    )


def _auto_count(length: float, support: float, maximum: int) -> int:
    return min(maximum, max(1, int(math.ceil(length / support - 1e-9))))


def _axis_positions(
    length: float, pitch: float, count: int, receiver: float, axis: str,
    offset: float = 0.0, end_margin: float | None = None,
    start_margin: float | None = None, first_index: int = 0, index_step: int = 1,
) -> list[float]:
    margin = PEGBOARD_EDGE_INSET + receiver / 2.0
    start = margin if start_margin is None else start_margin
    limit = length - (margin if end_margin is None else end_margin)
    candidates = [
        (index + 0.5) * pitch + offset
        for index in range(first_index, int(math.ceil(length / pitch)) + 1, index_step)
        if start - 1e-9 <= (index + 0.5) * pitch + offset <= limit + 1e-9
    ]
    if len(candidates) < count:
        raise ValueError(
            f"Cleat Count {axis} = {count} does not fit this {length:g} mm bin on the selected board grid"
        )
    if count == 1:
        return [min(candidates, key=lambda value: abs(value - length / 2.0))]
    indexes = [round(i * (len(candidates) - 1) / (count - 1)) for i in range(count)]
    return [candidates[index] for index in indexes]


def receiver_layout(box_or_x: Any, z: float | None = None, mount: PegboardMountSpec | None = None,
                    height: float | None = None) -> dict[str, Any]:
    """Receiver seats for a bin.

    ``height`` is the bin as it actually seats on the board (lid included).
    A built body can be shorter than that, so generation passes it explicitly;
    placement uses the inventory height, which is the same basis.
    """
    if hasattr(box_or_x, "x"):
        x = float(box_or_x.x)
        height = float(box_or_x.z if height is None else height)
        mount = normalise_mount_spec(getattr(box_or_x, "pegboard", mount))
    else:
        x = float(box_or_x)
        height = float(z)
        mount = normalise_mount_spec(mount)
    if not mount.enabled:
        return {"enabled": False, "receivers": [], "ribs": []}
    standard = pegboard_standard(mount.standard)
    count_x = _auto_count(x, PEGBOARD_AUTO_SUPPORT_X, PEGBOARD_MAX_CLEATS_X) \
        if mount.cleat_x == "auto" else int(mount.cleat_x)
    count_y = _auto_count(height, PEGBOARD_AUTO_SUPPORT_Y, PEGBOARD_MAX_CLEATS_Y) \
        if mount.cleat_y == "auto" else int(mount.cleat_y)
    # The universal body is fully concealed. A standard adapter takes a pair
    # of holes, so legal receiver rows are 1, 3, 5... (pairs 0/1, 2/3...).
    y_rules = dict(
        start_margin=PEGBOARD_CLEAT_BELOW_SEAT,
        end_margin=PEGBOARD_EDGE_INSET + PEGBOARD_RECEIVER_ABOVE_SEAT,
        first_index=standard.first_seat_row,
        index_step=standard.seat_row_stride,
    )
    if mount.cleat_y == "auto":
        while count_y > 1:
            try:
                _axis_positions(height, standard.pitch_y_mm, count_y,
                                PEGBOARD_RECEIVER_HEIGHT, "Y", **y_rules)
                break
            except ValueError:
                count_y -= 1
    zs = _axis_positions(height, standard.pitch_y_mm, count_y,
                         PEGBOARD_RECEIVER_HEIGHT, "Y", **y_rules)
    # SKÅDIS rows stagger. Auto X must fit every selected row, not just the
    # first one, and may step down when a narrow bin cannot fit its target.
    while True:
        try:
            row_xs = [
                _axis_positions(
                    x, standard.pitch_x_mm, count_x, PEGBOARD_RECEIVER_WIDTH,
                    "X", standard.stagger_x_mm
                    if round(pz / standard.pitch_y_mm - 0.5) % 2 else 0.0,
                )
                for pz in zs
            ]
            break
        except ValueError:
            if mount.cleat_x != "auto" or count_x <= 1:
                raise
            count_x -= 1
    receivers = []
    for row, pz in enumerate(zs):
        seat_grid_y = round(pz / standard.pitch_y_mm - 0.5)
        grid_y = seat_grid_y - (standard.board_holes_per_adapter - 1)
        for col, px in enumerate(row_xs[row]):
            receivers.append({
                "x": round(px - x / 2.0, 6), "z": round(pz, 6),
                "row": row, "column": col,
                "grid_x": round(px / standard.pitch_x_mm - 0.5, 6),
                "grid_y": int(grid_y),
            })
    unique_x = sorted({float(one["x"]) for one in receivers})
    ribs: list[float] = []
    safe_left = -x / 2.0 + PEGBOARD_EDGE_INSET + PEGBOARD_RIB_WIDTH / 2.0
    safe_right = x / 2.0 - PEGBOARD_EDGE_INSET - PEGBOARD_RIB_WIDTH / 2.0
    gaps = [(safe_left, unique_x[0] - PEGBOARD_RECEIVER_WIDTH / 2.0)]
    gaps.extend((left + PEGBOARD_RECEIVER_WIDTH / 2.0,
                 right - PEGBOARD_RECEIVER_WIDTH / 2.0)
                for left, right in zip(unique_x, unique_x[1:]))
    gaps.append((unique_x[-1] + PEGBOARD_RECEIVER_WIDTH / 2.0, safe_right))
    for left, right in gaps:
        gap = right - left
        if gap > PEGBOARD_MAX_UNSUPPORTED_GAP + 1e-9:
            extras = int(math.ceil(gap / PEGBOARD_MAX_UNSUPPORTED_GAP)) - 1
            ribs.extend(left + gap * i / (extras + 1) for i in range(1, extras + 1))
    return {
        "enabled": True,
        "standard": standard.id,
        "cleat_x": mount.cleat_x,
        "cleat_y": mount.cleat_y,
        "resolved_x": count_x,
        "resolved_y": count_y,
        "minimum_height_mm": round(max(one["z"] for one in receivers) +
                                   PEGBOARD_EDGE_INSET + PEGBOARD_RECEIVER_ABOVE_SEAT, 6),
        "receivers": receivers,
        "ribs": [round(value, 6) for value in ribs],
        "projection_mm": PEGBOARD_PROJECTION,
        "contact_plane_y": round(PEGBOARD_PROJECTION, 6),
    }


def pegboard_layout_for_bin(one: dict[str, Any], standard_id: Any) -> dict[str, Any]:
    standard = pegboard_standard(standard_id)
    stored_standard = str(one.get("pegboard_standard") or "").strip().lower()
    requested_standard = stored_standard or standard.id
    if requested_standard not in PEGBOARD_STANDARDS:
        requested_standard = standard.id
    mount = PegboardMountSpec(
        True,
        requested_standard,
        _count(one.get("cleat_x", "auto"), PEGBOARD_MAX_CLEATS_X, "X"),
        _count(one.get("cleat_y", "auto"), PEGBOARD_MAX_CLEATS_Y, "Y"),
    )
    layout = receiver_layout(float(one["x"]), float(one["z"]), mount)
    cells_x = max(1, int(math.ceil(float(one["x"]) / standard.pitch_x_mm - 1e-9)))
    cells_y = max(1, int(math.ceil(float(one["z"]) / standard.pitch_y_mm - 1e-9)))
    mounts = []
    for receiver in layout["receivers"]:
        for hole in range(standard.board_holes_per_adapter):
            mounts.append([receiver["grid_x"], receiver["grid_y"] + hole])
    return {
        **layout,
        "compatible": stored_standard == standard.id,
        "cells_x": cells_x,
        "cells_y": cells_y,
        "mount_offsets": mounts,
    }


def _box(extents: tuple[float, float, float], center: tuple[float, float, float]) -> trimesh.Trimesh:
    mesh = trimesh.creation.box(extents=np.asarray(extents, dtype=float))
    mesh.apply_translation(center)
    return mesh


def _prism_x(profile: list[tuple[float, float]], x0: float, x1: float) -> trimesh.Trimesh:
    """Extrude a convex Y/Z cleat profile across the bin width."""
    count = len(profile)
    vertices = np.asarray(
        [(x, y, z) for x in (x0, x1) for y, z in profile], dtype=float,
    )
    faces: list[tuple[int, int, int]] = []
    for index in range(1, count - 1):
        faces.extend([(0, index + 1, index), (count, count + index, count + index + 1)])
    for index in range(count):
        next_index = (index + 1) % count
        faces.extend([
            (index, next_index, count + next_index),
            (index, count + next_index, count + index),
        ])
    return trimesh.Trimesh(vertices=vertices, faces=faces, process=True)


def _receiver_guide_profile(back_y: float, seat_z: float) -> list[tuple[float, float]]:
    """45-degree lower start and a flat, rectangular-looking upper edge."""
    inner = back_y - 0.35
    outer = back_y + PEGBOARD_PROJECTION
    bottom = seat_z - PEGBOARD_CLEAT_BELOW_SEAT
    return [
        (inner, bottom),
        (outer, bottom + outer - inner),
        (outer, seat_z + PEGBOARD_RECEIVER_ABOVE_SEAT),
        (inner, seat_z + PEGBOARD_RECEIVER_ABOVE_SEAT),
    ]


def _adapter_body_profile(center: float) -> list[tuple[float, float]]:
    """The shared one-piece cleat section; no added front tongue."""
    return [
        (0.0, center - PEGBOARD_CLEAT_BELOW_SEAT),
        (PEGBOARD_PROJECTION, center - PEGBOARD_CLEAT_BELOW_SEAT),
        (PEGBOARD_PROJECTION, center - 2.3),
        (0.0, center + 3.2),
    ]


def _latch_mesh(center: float) -> trimesh.Trimesh:
    """Catch across the low end of the cleat slope (adapter coordinates)."""
    start = PEGBOARD_PROJECTION - PEGBOARD_LATCH_DEPTH
    top = center + PEGBOARD_LATCH_ABOVE_CENTER
    # Bottom sits inside the cleat body so the catch fuses to it.
    return _box(
        (PEGBOARD_LATCH_WIDTH, PEGBOARD_LATCH_DEPTH, top - (center - 2.6)),
        (0.0, start + PEGBOARD_LATCH_DEPTH / 2.0, (top + center - 2.6) / 2.0),
    )


def _receiver_mesh(cx: float, back_y: float, cz: float) -> trimesh.Trimesh:
    rail = 1.4
    side = (PEGBOARD_RECEIVER_WIDTH - rail) / 2.0
    guide = _receiver_guide_profile(back_y, cz)
    pieces = [
        _prism_x(guide, cx - PEGBOARD_RECEIVER_WIDTH / 2,
                 cx - PEGBOARD_RECEIVER_WIDTH / 2 + rail),
        _prism_x(guide, cx + PEGBOARD_RECEIVER_WIDTH / 2 - rail,
                 cx + PEGBOARD_RECEIVER_WIDTH / 2),
        # The underside mates with the entire narrow cleat body's sloped top.
        # The outside top stays flat; there is no decorative cap.
        _bridge_with_latch_notch(cx, back_y, cz),
    ]
    return union(pieces)


def _bridge_with_latch_notch(cx: float, back_y: float, cz: float) -> trimesh.Trimesh:
    """Receiver top, notched on its underside to take the cleat's catch."""
    bridge = _prism_x([
        (back_y - 0.35, cz - 2.1),
        (back_y + PEGBOARD_PROJECTION, cz + 3.4),
        (back_y + PEGBOARD_PROJECTION, cz + PEGBOARD_RECEIVER_ABOVE_SEAT),
        (back_y - 0.35, cz + PEGBOARD_RECEIVER_ABOVE_SEAT),
    ], cx - PEGBOARD_RECEIVER_WIDTH / 2, cx + PEGBOARD_RECEIVER_WIDTH / 2)
    # The catch spans the low (bin-side) end of the slope; the notch's
    # board-side wall sits just beyond the catch's board-side face.
    wall_y = back_y + PEGBOARD_LATCH_DEPTH + PEGBOARD_LATCH_CLEARANCE
    roof_z = (cz + PEGBOARD_LATCH_ABOVE_CENTER + 0.2 + PEGBOARD_LATCH_CLEARANCE)
    half = PEGBOARD_LATCH_WIDTH / 2.0 + PEGBOARD_LATCH_CLEARANCE
    floor_z = cz - 4.0
    notch = _box(
        (2.0 * half, wall_y - (back_y - 1.0), roof_z - floor_z),
        (cx, (wall_y + back_y - 1.0) / 2.0, (roof_z + floor_z) / 2.0),
    )
    return difference([bridge, notch])


def apply_pegboard_mount_structure(box_spec: Any, body: trimesh.Trimesh,
                                   height: float | None = None) -> trimesh.Trimesh:
    layout = receiver_layout(box_spec, height=height)
    if not layout["enabled"]:
        return body
    back_y = float(box_spec.y) / 2.0
    pieces = [body]
    pieces.extend(_receiver_mesh(float(one["x"]), back_y, float(one["z"])) for one in layout["receivers"])
    for x in layout["ribs"]:
        pieces.append(_box(
            (PEGBOARD_RIB_WIDTH, PEGBOARD_PROJECTION + 0.35, max(1.0, float(box_spec.z) - 2.0)),
            (float(x), back_y + PEGBOARD_PROJECTION / 2.0 - 0.175, float(box_spec.z) / 2.0),
        ))
    return union(pieces)


def _cylinder_y(radius: float, length: float, center: tuple[float, float, float]) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(radius=radius, height=length, sections=24)
    mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2.0, (1.0, 0.0, 0.0)))
    mesh.apply_translation(center)
    return mesh


def make_board_adapter(standard_id: Any, thickness_mm: Any = 3.2) -> trimesh.Trimesh:
    standard = pegboard_standard(standard_id)
    extension = max(0.0, _positive(thickness_mm, "board thickness") - 3.2)
    # One universal narrow body IS the cleat. Its top falls 5.5 mm over
    # 5.5 mm projection; only the board-facing (-Y) pegs/tabs vary.
    center = 42.4 if standard.id == "standard" else 8.0
    body = union([_prism_x(_adapter_body_profile(center), -5.0, 5.0), _latch_mesh(center)])
    if standard.id == "standard":
        straight = _cylinder_y(2.65, 8.0 + extension, (0.0, -3.65 - extension / 2, 17.0))
        hooked = _cylinder_y(2.65, 8.0 + extension, (0.0, -3.65 - extension / 2, 42.4))
        hook = _box((4.8, 3.0, 4.0), (0.0, -7.0 - extension, 40.2))
        board_parts = [straight, hooked, hook]
    else:
        # A single vertical SKÅDIS slot holds the tab and its locking hook;
        # adjacent slot rows stagger sideways and cannot take two straight tabs.
        tab = _box((4.4, 8.0 + extension, 12.0), (0.0, -3.65 - extension / 2, 8.0))
        hook = _box((4.4, 3.0, 3.0), (0.0, -7.0 - extension, 3.0))
        board_parts = [tab, hook]
    return union([body, *board_parts])


PEGBOARD_SUPPORT_BASE_WIDTH = 1.0   # break-away web, bed end
PEGBOARD_SUPPORT_NECK_WIDTH = 0.6   # break-away web, thin neck where it meets the pin/tab
PEGBOARD_SUPPORT_NECK_HEIGHT = 0.8


def _board_feature_undersides(standard: PegboardStandard, extension: float,
                              ) -> list[tuple[float, float, float, float]]:
    """(z, y0, y1, x_underside) for each board-facing pin/tab surface.

    Mirrors make_board_adapter.  x_underside is the lowest-x material at that
    z, i.e. the surface that faces the bed when the hook is laid on its side.
    """
    pin_y0 = -7.65 - extension
    if standard.id == "standard":
        pin_r = 2.65
        result = []
        for pin_z in (17.0, 42.4):
            for dz in (-1.3, 1.3):
                reach = math.sqrt(pin_r ** 2 - (abs(dz) + 0.3) ** 2)
                result.append((pin_z + dz, pin_y0, 0.35, -reach))
        result.append((40.2, -8.5 - extension, -5.5 - extension, -2.4))
        return result
    result = [(8.0 + dz, pin_y0, 0.35, -2.2) for dz in (-4.0, 0.0, 4.0)]
    result.append((3.0, -8.5 - extension, -5.5 - extension, -2.2))
    return result


def _hook_print_supports(standard: PegboardStandard, extension: float, bed_x: float) -> trimesh.Trimesh:
    """Thin break-away webs from the print bed up to each pin/tab underside.

    In the hook's printed orientation (width axis = build Z) the pins and tabs
    float above the bed; these webs make every one of them a supported span.
    Each web ends in a narrow neck so it snaps off with pliers; it must be
    removed before the hook goes into the board.  Webs stop at the adapter
    body (y ~ 0), so the board-facing envelope of the hook is unchanged.
    """
    webs = []
    y_end = 0.2                                  # fuses into the adapter body
    for z, y0, _y1, x_under in _board_feature_undersides(standard, extension):
        top = x_under + 0.3                      # neck tip, inside the pin/tab
        neck_bottom = top - PEGBOARD_SUPPORT_NECK_HEIGHT
        y_mid = (y0 + y_end) / 2.0
        length = y_end - y0
        # Webs are tall in X (toward the bed) and thin in Z (the width axis).
        base_top = neck_bottom + 0.1
        webs.append(_box(
            (base_top - bed_x, length, PEGBOARD_SUPPORT_BASE_WIDTH),
            ((base_top + bed_x) / 2.0, y_mid, z),
        ))
        webs.append(_box(
            (top - neck_bottom, length, PEGBOARD_SUPPORT_NECK_WIDTH),
            ((top + neck_bottom) / 2.0, y_mid, z),
        ))
    return union(webs)


def adapter_print_transform() -> np.ndarray:
    """Board-facing -Y becomes build +Z; the broad face rests on the bed."""
    return trimesh.transformations.rotation_matrix(-math.pi / 2.0, (1.0, 0.0, 0.0))


def make_board_adapters(box_spec: Any, thickness_mm: Any = 3.2,
                        height: float | None = None) -> list[tuple[str, trimesh.Trimesh]]:
    layout = receiver_layout(box_spec, height=height)
    if not layout["enabled"]:
        return []
    result = []
    for index, _receiver in enumerate(layout["receivers"], 1):
        mesh = make_board_adapter(layout["standard"], thickness_mm)
        # The broad front face rests on the bed; board pegs/tabs rise in +Z.
        mesh.apply_transform(adapter_print_transform())
        mesh.apply_translation((25.0 * ((index - 1) % 5),
                                40.0 * ((index - 1) // 5),
                                -float(mesh.bounds[0][2])))
        result.append((f"pegboard_adapter_{index}", mesh))
    return result


PEGBOARD_HOOK_MAX_COUNT = 8
PEGBOARD_HOOK_DEFAULT_COUNT = 4
PEGBOARD_HOOK_ARM_WIDTH = 10.0
PEGBOARD_HOOK_ARM_THICKNESS = 6.0
PEGBOARD_HOOK_DEFAULT_ARM_LENGTH = 50.0
PEGBOARD_HOOK_OVERLAP = 1.0
PEGBOARD_HOOK_ROOT_HEIGHT = 12.0
PEGBOARD_HOOK_ROOT_DEPTH = 3.0
PEGBOARD_HOOK_UPTURN_LENGTH = 14.0
PEGBOARD_HOOK_MIN_ARM_LENGTH = 10.0
PEGBOARD_HOOK_MAX_ARM_LENGTH = 150.0


def _hook_parts(standard_id: Any, arm_length_mm: float, thickness_mm: Any = 3.2) -> dict[str, trimesh.Trimesh]:
    """The board adapter plus the root, forward arm and upturn that join it.

    Every joint overlaps its neighbour by a real volume (not just a shared
    face), so the union cannot fall apart into touching-only bodies.
    """
    standard = pegboard_standard(standard_id)
    arm_length = float(arm_length_mm)
    if not math.isfinite(arm_length) or not (
        PEGBOARD_HOOK_MIN_ARM_LENGTH <= arm_length <= PEGBOARD_HOOK_MAX_ARM_LENGTH
    ):
        raise ValueError(
            f"Hook arm length must be {PEGBOARD_HOOK_MIN_ARM_LENGTH:g}-{PEGBOARD_HOOK_MAX_ARM_LENGTH:g} mm."
        )
    base = make_board_adapter(standard.id, thickness_mm)
    extension = max(0.0, _positive(thickness_mm, "board thickness") - 3.2)
    support = _hook_print_supports(standard, extension, float(base.bounds[0][0]))
    center = 42.4 if standard.id == "standard" else 8.0
    profile = _adapter_body_profile(center)
    front_y = max(y for y, _z in profile)
    low_z = min(z for _y, z in profile)
    half = PEGBOARD_HOOK_ARM_WIDTH / 2.0
    thick = PEGBOARD_HOOK_ARM_THICKNESS
    overlap = PEGBOARD_HOOK_OVERLAP

    # The root starts inside the shared body and ends a little proud of its
    # front face; the arm then starts inside the root.
    root_y0 = front_y - overlap
    root_y1 = front_y + PEGBOARD_HOOK_ROOT_DEPTH
    root = _box(
        (PEGBOARD_HOOK_ARM_WIDTH, root_y1 - root_y0, PEGBOARD_HOOK_ROOT_HEIGHT),
        (0.0, (root_y0 + root_y1) / 2.0, low_z + PEGBOARD_HOOK_ROOT_HEIGHT / 2.0),
    )
    arm_y0 = root_y1 - overlap
    arm_y1 = front_y + arm_length
    arm = _box(
        (PEGBOARD_HOOK_ARM_WIDTH, arm_y1 - arm_y0, thick),
        (0.0, (arm_y0 + arm_y1) / 2.0, low_z + thick / 2.0),
    )

    # 45-degree upturn: starts inside the arm's far end, then rises and keeps
    # leaning forward so a hung item cannot slide off.
    lean = math.sqrt(0.5)
    run = PEGBOARD_HOOK_UPTURN_LENGTH * lean
    upturn = _prism_x([
        (arm_y1 - overlap, low_z),
        (arm_y1, low_z),
        (arm_y1 + run, low_z + run),
        (arm_y1 + run - thick * lean, low_z + run + thick * lean),
        (arm_y1 - overlap, low_z + thick),
    ], -half, half)
    return {"base": base, "root": root, "arm": arm, "upturn": upturn, "support": support}


def make_pegboard_hook(standard_id: Any, arm_length_mm: float = PEGBOARD_HOOK_DEFAULT_ARM_LENGTH, thickness_mm: Any = 3.2) -> trimesh.Trimesh:
    """One printable hook: the unchanged board adapter + root + forward arm + upturn.

    Built in adapter coordinates: the board faces -Y, the arm projects toward +Y.
    """
    return union(list(_hook_parts(standard_id, arm_length_mm, thickness_mm).values()))


def hook_print_transform() -> np.ndarray:
    """Lay the hook on its side so the arm's layers run along its length.

    Local to hook printing; adapter/receiver print orientation is untouched.
    """
    return trimesh.transformations.rotation_matrix(-math.pi / 2.0, (0.0, 1.0, 0.0))


def pegboard_hook_count(value: Any = None) -> int:
    if value is None or value == "":
        return PEGBOARD_HOOK_DEFAULT_COUNT
    if isinstance(value, bool) or isinstance(value, float) and not value.is_integer():
        raise ValueError(f"Hook count must be a whole number from 1 to {PEGBOARD_HOOK_MAX_COUNT}.")
    try:
        count = int(value)
    except (TypeError, ValueError):
        raise ValueError(f"Hook count must be a whole number from 1 to {PEGBOARD_HOOK_MAX_COUNT}.") from None
    if not 1 <= count <= PEGBOARD_HOOK_MAX_COUNT:
        raise ValueError(f"Hook count must be from 1 to {PEGBOARD_HOOK_MAX_COUNT}.")
    return count


def make_pegboard_hooks(
    standard_id: Any,
    count: int = PEGBOARD_HOOK_DEFAULT_COUNT,
    arm_length_mm: float = PEGBOARD_HOOK_DEFAULT_ARM_LENGTH,
    thickness_mm: Any = 3.2,
) -> list[tuple[str, trimesh.Trimesh]]:
    """`count` identical hooks, laid out flat on a plate and named pegboard_hook_N."""
    count = pegboard_hook_count(count)
    standard = pegboard_standard(standard_id)
    template = make_pegboard_hook(standard.id, arm_length_mm, thickness_mm)
    template.apply_transform(hook_print_transform())
    extent = template.bounds[1] - template.bounds[0]
    gap = 5.0
    per_row = 4
    result = []
    for index in range(count):
        mesh = template.copy()
        row, column = divmod(index, per_row)
        mesh.apply_translation((
            column * (float(extent[0]) + gap) - float(template.bounds[0][0]),
            row * (float(extent[1]) + gap) - float(template.bounds[0][1]),
            -float(template.bounds[0][2]),
        ))
        result.append((f"pegboard_hook_{index + 1}", mesh))
    return result
