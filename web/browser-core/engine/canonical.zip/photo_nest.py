"""Turn one overhead part photo on a reference sheet into a scaled outline."""

from __future__ import annotations

import base64
import binascii
import math
from dataclasses import dataclass
from typing import Iterable

import cv2
import numpy as np
from shapely.geometry import Polygon
from shapely.geometry.polygon import orient


LETTER_WIDTH_MM = 215.9
LETTER_HEIGHT_MM = 279.4
PAPER_SIZES_MM = {
    "letter": (LETTER_WIDTH_MM, LETTER_HEIGHT_MM),
    "a4": (210.0, 297.0),
}
WARP_PIXELS_PER_MM = 4.0
MAX_IMAGE_PIXELS = 32_000_000
MAX_UPLOAD_BYTES = 18_000_000
ACCEPTED_IMAGE_TYPES = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
}
SENSITIVITY_DEFAULT = 50.0
CLEANUP_DEFAULT = 50.0


def _cross2(a: np.ndarray, b: np.ndarray) -> float:
    return float(a[0] * b[1] - a[1] * b[0])


@dataclass(frozen=True)
class PhotoOutline:
    contour: tuple[tuple[float, float], ...]
    width: float
    depth: float
    paper_corners: tuple[tuple[float, float], ...]
    reference_image: str | None = None
    reference_bounds: tuple[float, float, float, float] | None = None
    # The full rectified Letter-sheet image, for later retracing without
    # repeating paper detection or perspective correction. Kept only in
    # browser session state - never written into a saved design.
    rectified_image: str | None = None
    # The contour's own centre in the rectified sheet's stable millimetre
    # frame - lets the browser translate a later retrace's differently
    # centred contour back into the currently accepted one's frame, so the
    # two (and the reference photo) stay one consistent physical overlay.
    trace_center_mm: tuple[float, float] | None = None


def _resolve_threshold(otsu: float, sensitivity: float) -> float:
    """Object sensitivity (0-100, 50 = automatic) as a segmentation threshold."""
    sensitivity = max(0.0, min(100.0, float(sensitivity)))
    auto_threshold = max(14.0, min(70.0, float(otsu)))
    offset = (sensitivity - 50.0) * 0.4
    return max(8.0, min(90.0, auto_threshold - offset))


def _cleanup_scales(cleanup: float) -> tuple[float, float, float, float]:
    """``(open_mm, close_mm, blur_sigma_mm, approx_epsilon_mm)`` at this Edge
    cleanup setting (0-100, more detail to smoother). 50 reproduces the
    original fixed pipeline exactly."""
    cleanup = max(0.0, min(100.0, float(cleanup)))
    t = cleanup / 100.0
    return (0.25 + 0.80 * t, 0.55 + 1.40 * t, 0.10 + 0.36 * t, 0.15 + 0.40 * t)


def _encode_jpeg_data_url(image: np.ndarray, quality: int = 86) -> str:
    ok, encoded = cv2.imencode(".jpg", image, [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok:
        raise ValueError("the selected photo could not be prepared for outline editing")
    return "data:image/jpeg;base64," + base64.b64encode(encoded.tobytes()).decode("ascii")


def decode_image_data(data_url: str, mime_type: str = "") -> np.ndarray:
    """Decode a browser data URL without retaining the uploaded bytes."""
    if not isinstance(data_url, str) or "," not in data_url:
        raise ValueError("choose a JPG, JPEG, PNG, or WEBP photo")
    header, encoded = data_url.split(",", 1)
    declared = header[5:].split(";", 1)[0].lower() if header.startswith("data:") else ""
    chosen = (mime_type or declared).lower()
    if chosen not in ACCEPTED_IMAGE_TYPES or (declared and declared not in ACCEPTED_IMAGE_TYPES):
        raise ValueError("choose a JPG, JPEG, PNG, or WEBP photo")
    try:
        payload = base64.b64decode(encoded, validate=True)
    except (binascii.Error, ValueError) as error:
        raise ValueError("the selected photo could not be read") from error
    if not payload or len(payload) > MAX_UPLOAD_BYTES:
        raise ValueError("the photo must be smaller than 18 MB")
    
    # Check dimensions before decompressing to avoid OOM bombs
    try:
        from PIL import Image
        import io
        with Image.open(io.BytesIO(payload)) as img:
            if img.width * img.height > MAX_IMAGE_PIXELS:
                raise ValueError("the photo is too large; use an image under 32 megapixels")
    except ValueError:
        raise
    except Exception as error:
        raise ValueError("the selected photo could not be read") from error

    image = cv2.imdecode(np.frombuffer(payload, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError("the selected photo could not be read")
    return image


def order_paper_corners(points: Iterable[Iterable[float]]) -> np.ndarray:
    """Return four corners clockwise as top-left, top-right, bottom-right, bottom-left."""
    corners = np.asarray(tuple(points), dtype=np.float32)
    if corners.shape != (4, 2) or not np.isfinite(corners).all():
        raise ValueError("paper detection needs four valid corners")
    centre = corners.mean(axis=0)
    angles = np.arctan2(corners[:, 1] - centre[1], corners[:, 0] - centre[0])
    corners = corners[np.argsort(angles)]
    start = int(np.argmin(corners[:, 0] + corners[:, 1]))
    corners = np.roll(corners, -start, axis=0)
    # atan2 order is TL, TR, BR, BL in image coordinates. Correct a rare
    # counter-clockwise input before checking the perspective.
    cross = _cross2(corners[1] - corners[0], corners[2] - corners[1])
    if cross < 0:
        corners = corners[[0, 3, 2, 1]]
    return corners.astype(np.float32)


def validate_paper_corners(points: Iterable[Iterable[float]]) -> np.ndarray:
    corners = order_paper_corners(points)
    edges = np.array([
        np.linalg.norm(corners[(index + 1) % 4] - corners[index])
        for index in range(4)
    ])
    if edges.min() < 30.0:
        raise ValueError("paper missing: all four letter-paper corners must be visible")
    if edges.max() / edges.min() > 5.0:
        raise ValueError("perspective too severe: hold the camera directly overhead")
    area = abs(float(cv2.contourArea(corners)))
    rect_area = float((corners[:, 0].max() - corners[:, 0].min())
                      * (corners[:, 1].max() - corners[:, 1].min()))
    if rect_area <= 0.0 or area / rect_area < 0.48:
        raise ValueError("perspective too severe: hold the camera directly overhead")
    for index in range(4):
        before = corners[index - 1] - corners[index]
        after = corners[(index + 1) % 4] - corners[index]
        sine = abs(_cross2(before, after)) / (
            float(np.linalg.norm(before) * np.linalg.norm(after)) + 1e-12
        )
        if sine < 0.28:
            raise ValueError("perspective too severe: hold the camera directly overhead")
    return corners


def _quad_candidates(mask: np.ndarray, scale: float) -> list[np.ndarray]:
    contours, _hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    minimum = mask.shape[0] * mask.shape[1] * 0.12
    candidates: list[np.ndarray] = []
    for contour in contours:
        area = abs(float(cv2.contourArea(contour)))
        if area < minimum:
            continue
        perimeter = cv2.arcLength(contour, True)
        for fraction in (0.012, 0.018, 0.025, 0.035, 0.05):
            approx = cv2.approxPolyDP(contour, fraction * perimeter, True)
            if len(approx) == 4 and cv2.isContourConvex(approx):
                candidates.append(approx[:, 0, :].astype(np.float32) / scale)
                break
    return candidates


def detect_paper_corners(image: np.ndarray) -> np.ndarray:
    """Find the largest plausible four-cornered sheet in a photograph."""
    if image is None or image.ndim != 3 or min(image.shape[:2]) < 120:
        raise ValueError("paper missing: use a clear photo showing the entire sheet")
    height, width = image.shape[:2]
    scale = min(1.0, 1800.0 / max(height, width))
    work = cv2.resize(image, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    gray = cv2.cvtColor(work, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (7, 7), 0)
    edges = cv2.Canny(blur, 35, 120)
    edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8), iterations=2)

    hsv = cv2.cvtColor(work, cv2.COLOR_BGR2HSV)
    bright = cv2.inRange(hsv, np.array((0, 0, 115), np.uint8), np.array((179, 125, 255), np.uint8))
    bright = cv2.morphologyEx(bright, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8), iterations=2)

    candidates = _quad_candidates(edges, scale) + _quad_candidates(bright, scale)
    ranked: list[tuple[float, np.ndarray]] = []
    for candidate in candidates:
        try:
            ordered = validate_paper_corners(candidate)
        except ValueError:
            continue
        if (ordered[:, 0].min() <= 2.0 or ordered[:, 1].min() <= 2.0
                or ordered[:, 0].max() >= width - 3.0
                or ordered[:, 1].max() >= height - 3.0):
            continue
        area = abs(float(cv2.contourArea(ordered)))
        ranked.append((area, ordered))
    if not ranked:
        raise ValueError("paper missing: show all four corners of the selected reference sheet")
    return max(ranked, key=lambda entry: entry[0])[1]


def _paper_size_mm(paper_size: str) -> tuple[float, float]:
    if paper_size not in PAPER_SIZES_MM:
        raise ValueError(f"paper size must be one of {', '.join(PAPER_SIZES_MM)}")
    return PAPER_SIZES_MM[paper_size]


def perspective_transform_inputs(
    points: Iterable[Iterable[float]], pixels_per_mm: float = WARP_PIXELS_PER_MM,
    paper_size: str = "letter",
) -> tuple[np.ndarray, np.ndarray, tuple[int, int]]:
    """Validated source/destination points used for the reference-sheet homography."""
    source = validate_paper_corners(points)
    paper_width_mm, paper_height_mm = _paper_size_mm(paper_size)
    horizontal = (np.linalg.norm(source[1] - source[0]) + np.linalg.norm(source[2] - source[3])) / 2.0
    vertical = (np.linalg.norm(source[2] - source[1]) + np.linalg.norm(source[3] - source[0])) / 2.0
    if horizontal > vertical:
        source = source[[1, 2, 3, 0]]
    width = max(2, int(round(paper_width_mm * pixels_per_mm)))
    height = max(2, int(round(paper_height_mm * pixels_per_mm)))
    destination = np.array(
        [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]],
        dtype=np.float32,
    )
    return source, destination, (width, height)


def correct_perspective(
    image: np.ndarray, points: Iterable[Iterable[float]],
    pixels_per_mm: float = WARP_PIXELS_PER_MM,
    paper_size: str = "letter",
) -> np.ndarray:
    source, destination, size = perspective_transform_inputs(points, pixels_per_mm, paper_size)
    transform = cv2.getPerspectiveTransform(source, destination)
    condition = float(np.linalg.cond(transform))
    if not math.isfinite(condition) or condition > 1e8:
        raise ValueError("perspective too severe: hold the camera directly overhead")
    return cv2.warpPerspective(image, transform, size, flags=cv2.INTER_CUBIC,
                               borderMode=cv2.BORDER_REPLICATE)


def clean_outline_mask(
    mask: np.ndarray, pixels_per_mm: float, cleanup: float = CLEANUP_DEFAULT,
) -> np.ndarray:
    """Remove camera specks and smooth sub-millimetre mask stair-steps."""
    open_mm, close_mm, blur_sigma_mm, _epsilon_mm = _cleanup_scales(cleanup)
    binary = (mask > 0).astype(np.uint8) * 255
    small = max(3, int(round(open_mm * pixels_per_mm)) | 1)
    large = max(3, int(round(close_mm * pixels_per_mm)) | 1)
    binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, np.ones((small, small), np.uint8))
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, np.ones((large, large), np.uint8))
    sigma = max(0.6, blur_sigma_mm * pixels_per_mm)
    blurred = cv2.GaussianBlur(binary, (0, 0), sigma)
    return (blurred >= 127).astype(np.uint8) * 255


def segment_object(
    rectified: np.ndarray, pixels_per_mm: float = WARP_PIXELS_PER_MM,
    sensitivity: float = SENSITIVITY_DEFAULT, cleanup: float = CLEANUP_DEFAULT,
) -> tuple[np.ndarray, np.ndarray]:
    """Return the single cleaned foreground component and its outside contour."""
    lab = cv2.cvtColor(rectified, cv2.COLOR_BGR2LAB).astype(np.float32)
    margin = max(4, int(round(5.0 * pixels_per_mm)))
    corner = max(margin + 2, int(round(16.0 * pixels_per_mm)))
    samples = np.concatenate([
        lab[margin:corner, margin:corner].reshape(-1, 3),
        lab[margin:corner, -corner:-margin].reshape(-1, 3),
        lab[-corner:-margin, margin:corner].reshape(-1, 3),
        lab[-corner:-margin, -corner:-margin].reshape(-1, 3),
    ])
    background = np.median(samples, axis=0)
    distance = np.linalg.norm(lab - background, axis=2)
    distance8 = np.clip(distance, 0, 255).astype(np.uint8)
    otsu, _ = cv2.threshold(distance8, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    threshold = _resolve_threshold(float(otsu), sensitivity)
    raw = (distance > threshold).astype(np.uint8) * 255
    raw = clean_outline_mask(raw, pixels_per_mm, cleanup)

    count, labels, stats, _centres = cv2.connectedComponentsWithStats(raw, 8)
    components = []
    pixel_area = 1.0 / (pixels_per_mm * pixels_per_mm)
    for label in range(1, count):
        area_mm2 = float(stats[label, cv2.CC_STAT_AREA]) * pixel_area
        if area_mm2 >= 20.0:
            components.append((area_mm2, label, stats[label]))
    if not components:
        raise ValueError("outline too small or noisy: use a closer, sharper, high-contrast photo")
    components.sort(reverse=True)
    largest_area = components[0][0]
    meaningful = [entry for entry in components if entry[0] >= max(35.0, largest_area * 0.10)]
    if len(meaningful) != 1:
        raise ValueError("multiple objects found: place exactly one part on the paper")
    _area, label, stat = meaningful[0]
    edge = max(2, int(round(2.5 * pixels_per_mm)))
    x, y, width, height, _pixels = (int(value) for value in stat)
    if x <= edge or y <= edge or x + width >= raw.shape[1] - edge or y + height >= raw.shape[0] - edge:
        raise ValueError("object touching paper edge: leave visible paper around the entire part")

    chosen = (labels == label).astype(np.uint8) * 255
    contours, _hierarchy = cv2.findContours(chosen, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        raise ValueError("outline too small or noisy: use a closer, sharper photo")
    outside = max(contours, key=cv2.contourArea)
    _open_mm, _close_mm, _blur_mm, approx_epsilon_mm = _cleanup_scales(cleanup)
    epsilon = max(1.0, approx_epsilon_mm * pixels_per_mm)
    outside = cv2.approxPolyDP(outside, epsilon, True)
    return chosen, outside[:, 0, :].astype(np.float64)


def contour_to_millimetres(
    pixels: np.ndarray, pixels_per_mm: float = WARP_PIXELS_PER_MM,
) -> tuple[tuple[tuple[float, float], ...], tuple[float, float]]:
    """The contour, centred on its own bounding box as always, plus that
    centre in the rectified sheet's own stable millimetre frame - the same
    frame on every trace of the same rectified image, so a browser can
    compare two traces' centres directly (see spec: one stable coordinate
    frame for scan tuning)."""
    polygon, centre_x, centre_y = _contour_polygon_millimetres(pixels, pixels_per_mm)
    points = tuple(
        (round(float(x - centre_x), 3), round(float(y - centre_y), 3))
        for x, y in list(polygon.exterior.coords)[:-1]
    )
    if len(points) < 3 or len(points) > 500:
        raise ValueError("outline too small or noisy: simplify the background and retake the photo")
    return points, (round(float(centre_x), 3), round(float(centre_y), 3))


def _contour_polygon_millimetres(
    pixels: np.ndarray, pixels_per_mm: float,
) -> tuple[Polygon, float, float]:
    """Return the cleaned source-space polygon and the centre used by the editor."""
    coords = np.asarray(pixels, dtype=float) / pixels_per_mm
    if coords.ndim != 2 or coords.shape[1] != 2 or len(coords) < 3:
        raise ValueError("outline too small or noisy: no closed shape was found")
    coords[:, 1] *= -1.0
    polygon = Polygon(coords).buffer(0)
    if polygon.geom_type == "MultiPolygon":
        polygon = max(polygon.geoms, key=lambda one: one.area)
    if not isinstance(polygon, Polygon) or polygon.is_empty:
        raise ValueError("outline too small or noisy: no closed shape was found")
    polygon = orient(polygon.simplify(0.2, preserve_topology=True), sign=1.0)
    min_x, min_y, max_x, max_y = polygon.bounds
    if polygon.area < 25.0 or min(max_x - min_x, max_y - min_y) < 4.0:
        raise ValueError("outline too small or noisy: use a closer, sharper photo")
    centre_x, centre_y = (min_x + max_x) / 2.0, (min_y + max_y) / 2.0
    return polygon, centre_x, centre_y


def _reference_crop(
    rectified: np.ndarray, pixels: np.ndarray, pixels_per_mm: float,
) -> tuple[str, tuple[float, float, float, float]]:
    """Small rectified photo and its bounds in the contour's local coordinates."""
    _polygon, centre_x, centre_y = _contour_polygon_millimetres(pixels, pixels_per_mm)
    min_px = np.floor(pixels.min(axis=0)).astype(int)
    max_px = np.ceil(pixels.max(axis=0)).astype(int)
    padding = max(8, int(round(10.0 * pixels_per_mm)))
    x0 = max(0, int(min_px[0]) - padding)
    y0 = max(0, int(min_px[1]) - padding)
    x1 = min(rectified.shape[1], int(max_px[0]) + padding + 1)
    y1 = min(rectified.shape[0], int(max_px[1]) + padding + 1)
    crop = rectified[y0:y1, x0:x1]
    data_url = _encode_jpeg_data_url(crop)
    bounds = (
        round(x0 / pixels_per_mm - centre_x, 3),
        round(-y1 / pixels_per_mm - centre_y, 3),
        round(x1 / pixels_per_mm - centre_x, 3),
        round(-y0 / pixels_per_mm - centre_y, 3),
    )
    return data_url, bounds


def extract_photo_outline(
    image: np.ndarray, paper_size: str = "letter",
    sensitivity: float = SENSITIVITY_DEFAULT, cleanup: float = CLEANUP_DEFAULT,
    paper_corners: Iterable[Iterable[float]] | None = None,
) -> PhotoOutline:
    """Full scan: paper detection (or supplied corners), perspective
    correction, segmentation, cleanup and contour extraction."""
    _paper_size_mm(paper_size)
    corners = (
        validate_paper_corners(paper_corners) if paper_corners is not None
        else detect_paper_corners(image)
    )
    rectified = correct_perspective(image, corners, paper_size=paper_size)
    _mask, pixels = segment_object(rectified, WARP_PIXELS_PER_MM, sensitivity, cleanup)
    contour, trace_center_mm = contour_to_millimetres(pixels)
    reference_image, reference_bounds = _reference_crop(
        rectified, pixels, WARP_PIXELS_PER_MM
    )
    rectified_image = _encode_jpeg_data_url(rectified, quality=80)
    polygon = Polygon(contour)
    min_x, min_y, max_x, max_y = polygon.bounds
    return PhotoOutline(
        contour,
        round(max_x - min_x, 3),
        round(max_y - min_y, 3),
        tuple((round(float(x), 3), round(float(y), 3)) for x, y in corners),
        reference_image,
        reference_bounds,
        rectified_image,
        trace_center_mm,
    )


def photo_outline_from_data(
    data_url: str, mime_type: str = "", paper_size: str = "letter",
    sensitivity: float = SENSITIVITY_DEFAULT, cleanup: float = CLEANUP_DEFAULT,
    paper_corners: Iterable[Iterable[float]] | None = None,
) -> PhotoOutline:
    return extract_photo_outline(
        decode_image_data(data_url, mime_type), paper_size, sensitivity, cleanup, paper_corners,
    )


def retrace_outline_from_rectified(
    data_url: str, mime_type: str = "image/jpeg",
    sensitivity: float = SENSITIVITY_DEFAULT, cleanup: float = CLEANUP_DEFAULT,
) -> PhotoOutline:
    """Re-tune an already-rectified reference sheet: segmentation, cleanup and
    contour extraction only - paper detection and perspective correction are
    not repeated for every slider adjustment."""
    rectified = decode_image_data(data_url, mime_type or "image/jpeg")
    _mask, pixels = segment_object(rectified, WARP_PIXELS_PER_MM, sensitivity, cleanup)
    contour, trace_center_mm = contour_to_millimetres(pixels)
    reference_image, reference_bounds = _reference_crop(
        rectified, pixels, WARP_PIXELS_PER_MM
    )
    polygon = Polygon(contour)
    min_x, min_y, max_x, max_y = polygon.bounds
    return PhotoOutline(
        contour,
        round(max_x - min_x, 3),
        round(max_y - min_y, 3),
        (),
        reference_image,
        reference_bounds,
        None,
        trace_center_mm,
    )
