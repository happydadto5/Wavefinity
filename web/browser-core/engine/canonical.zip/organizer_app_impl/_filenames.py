"""Wavefinity output file naming and part-spec helpers."""

from __future__ import annotations

import argparse
import math
from pathlib import Path
import re
from organizer_engine import (
    BoxSpec,
    ConnectorSpec,
    DEFAULT_WALL,
    LOCKED_CONNECTOR_HEIGHT,
    LOCKED_CONNECTOR_LENGTH,
    LOCKED_TOLERANCE,
    DEFAULT_ARM_THICKNESS,
    lid_spec,
    lid_receives_stack,
)
from organizer_features.pegboard import pegboard_standard
from organizer_features.stack import stack_effective_box
from organizer_inserts import Layout, divider_cells

from ._common import clean_label, base_height


def _box_spec(args: argparse.Namespace, prefix: str = "") -> BoxSpec:
    key = f"{prefix}_" if prefix else ""
    return BoxSpec(
        x=getattr(args, f"{key}x"),
        y=getattr(args, f"{key}y"),
        z=getattr(args, f"{key}z"),
        wall=getattr(args, f"{key}wall"),
        flat_inside=getattr(args, f"{key}flat_inside"),
        base_thickness=getattr(args, f"{key}base_thickness"),
        standard_walls=math.isclose(
            getattr(args, f"{key}wall"), DEFAULT_WALL, abs_tol=1e-9
        ),
    )


def _connector_spec(args: argparse.Namespace) -> ConnectorSpec:
    return ConnectorSpec(tolerance=args.tolerance, height=args.height)


def _part_result(output: Path, report: dict, fit: object = None) -> dict[str, object]:
    result: dict[str, object] = {"output": str(output.resolve()), "mesh": report}
    if fit is not None:
        result["fit"] = fit
    return result


BIN_SERIAL = re.compile(r"B[0-9]+")


def with_serial(filename: str, serial: str) -> str:
    """``Box 16 x 48 x 40 Driver Rack.3mf`` -> ``Box 16 x 48 x 40 Driver Rack B7.3mf``.

    The bin's unique id always ends the name, before the extension, so a
    bin's files are identifiable as that bin's and two bins can never share
    a file name even when their names match. An empty serial changes nothing.
    """
    if not serial:
        return filename
    if not BIN_SERIAL.fullmatch(serial):
        raise ValueError(f"not a bin serial: {serial!r}")
    path = Path(filename)
    return f"{path.stem} {serial}{path.suffix}"


def grid_filename_segment(grid: str | None, x: float, y: float) -> str:
    """Nominal cells belong to the design, never inferred from mesh bounds."""
    if grid is None or grid == "wavefinity":
        return ""
    from organizer_engine._specs import GRID_PITCHES, validate_grid
    pitch = GRID_PITCHES[validate_grid(grid)]
    return f" Gridfinity {pitch:g}mm {x / pitch:g}x{y / pitch:g}u"


def box_filename(box: BoxSpec, part: str = "", suffix: str = ".3mf", *, grid: str | None = None) -> str:
    """``Box 16 x 48 x 40 Driver Rack.3mf``.

    The part name is the only thing that names a file. Lettering on the part
    is an interior part in its own right - there can be several, and which of
    them would stand for the whole file is not a question with an answer - so
    text no longer appears here. Seed the part name from the first label if
    you want the old behaviour; the editor offers to do exactly that.
    """
    name = f"Box {box.x:g} x {box.y:g} x {box.z:g}"
    if not math.isclose(box.wall, DEFAULT_WALL, abs_tol=1e-9):
        name += f" Wall {box.wall:g}mm"
    tidy = clean_label(part)
    if tidy:
        name += f" {tidy}"
    return name + grid_filename_segment(grid, box.x, box.y) + suffix


def edge_mount_label_filename(box: BoxSpec, part: str = "", suffix: str = ".3mf", *, grid: str | None = None) -> str:
    name = f"Edge Mount Label {box.x:g} x {box.y:g}"
    tidy = clean_label(part)
    return (f"{name} {tidy}" if tidy else name) + grid_filename_segment(grid, box.x, box.y) + suffix


def pegboard_adapter_filename(box: BoxSpec, part: str = "", suffix: str = ".3mf", *, grid: str | None = None) -> str:
    name = f"Pegboard Adapters {pegboard_standard(box.pegboard.standard).name} {box.x:g} x {box.z:g}"
    tidy = clean_label(part)
    return (f"{name} {tidy}" if tidy else name) + grid_filename_segment(grid, box.x, box.y) + suffix


def lid_filename(box: BoxSpec, part: str = "", suffix: str = ".3mf", *, grid: str | None = None) -> str:
    """The ordinary bin's matching removable lid."""
    effective = stack_effective_box(box)
    lid_name = "Stack Lid" if lid_receives_stack(box) else ("Gridfinity Lid" if grid == "gridfinity" else "Handled Lid")
    name = f"{lid_name} {box.x:g} x {box.y:g}"
    if not math.isclose(effective.wall, DEFAULT_WALL, abs_tol=1e-9):
        name += f" Wall {effective.wall:g}mm"
    tidy = clean_label(part)
    if tidy:
        name += f" {tidy}"
    return name + grid_filename_segment(grid, box.x, box.y) + suffix


def stack_lid_filename(box: BoxSpec, part: str = "", suffix: str = ".3mf", *, grid: str | None = None) -> str:
    """Compatibility name for callers of the former stack-only helper."""
    return lid_filename(box, part, suffix, grid=grid)


def lid_label_regions(
    box: BoxSpec, layout: Layout,
) -> list[tuple[str, tuple[float, float, float, float]]]:
    """Resolve lid labels from the Divider's authoritative compartments."""
    spec = lid_spec(box)
    if not spec.label_enabled:
        return []
    divider = next((one for one in layout.features if one.kind == "divider"), None)
    if divider is None:
        return []
    cells = divider_cells(stack_effective_box(box), divider, base_height(stack_effective_box(box), layout.mode))
    columns = max((cell.column_end for cell in cells), default=0)
    labels = list(spec.division_labels)
    regions: list[tuple[str, tuple[float, float, float, float]]] = []
    for cell in cells:
        index = cell.row * columns + cell.column
        text = labels[index] if index < len(labels) else ""
        regions.append((str(text or ""), (
            cell.zone.x0, cell.zone.y0, cell.zone.x1, cell.zone.y1,
        )))
    return regions


def insert_filename(
    box: BoxSpec,
    part: str = "",
    cartridge: bool = False,
    suffix: str = ".3mf",
    *, grid: str | None = None,
) -> str:
    prefix = "Cartridge" if cartridge else "Insert"
    name = f"{prefix} {box.x:g} x {box.y:g}"
    if not math.isclose(box.wall, DEFAULT_WALL, abs_tol=1e-9):
        name += f" Wall {box.wall:g}mm"
    tidy = clean_label(part)
    if tidy:
        name += f" {tidy}"
    return name + grid_filename_segment(grid, box.x, box.y) + suffix


def connector_filename(
    connector: ConnectorSpec | None = None,
    length: float = LOCKED_CONNECTOR_LENGTH,
    bin_a_height: float | None = None,
    bin_b_height: float | None = None,
    arm_thickness: float | None = None,
    different_heights: bool = False,
    suffix: str = ".3mf",
    wall: float = DEFAULT_WALL,
) -> str:
    tolerance = LOCKED_TOLERANCE if connector is None else connector.tolerance
    height = LOCKED_CONNECTOR_HEIGHT if connector is None else connector.height
    effective_arm = (
        arm_thickness
        if arm_thickness is not None
        else (DEFAULT_ARM_THICKNESS if connector is None else connector.arm_thickness)
    )

    diff = []
    if not math.isclose(wall, DEFAULT_WALL, abs_tol=1e-9):
        diff.append(f"Wall {wall:g}mm")
    if different_heights and bin_a_height is not None and bin_b_height is not None:
        if abs(bin_a_height - bin_b_height) > 1e-6:
            diff.append(f"{bin_a_height:g}mm to {bin_b_height:g}mm")

    if abs(tolerance - LOCKED_TOLERANCE) > 1e-6:
        diff.append(f"Tol {tolerance:g}mm")
    if abs(height - LOCKED_CONNECTOR_HEIGHT) > 1e-6:
        diff.append(f"Height {height:g}mm")
    if abs(length - LOCKED_CONNECTOR_LENGTH) > 1e-6:
        diff.append(f"Len {length:g}mm")
    if abs(effective_arm - DEFAULT_ARM_THICKNESS) > 1e-6:
        diff.append(f"Arm {effective_arm:g}mm")

    if not diff:
        return f"Connector - Same height{suffix}"
    return f"Connector - {' '.join(diff)}{suffix}"


SIZE_LIKE = re.compile(r"^\s*\d+(\.\d+)?\s*(mm)?\s*$", re.IGNORECASE)


def part_name_seed(text: str) -> str:
    """The part name a piece of lettering should seed, or ``""``.

    A label that is just a size - "8", "12mm" - names a compartment, not the
    part, so it is never promoted to the filename.
    """
    tidy = str(text or "").strip()
    if not tidy or SIZE_LIKE.match(tidy):
        return ""
    return tidy


#: Filename-component limit, in bytes, on the filesystems Wavefinity targets
#: (ext4, APFS and NTFS all cap the final component at 255 bytes).
MAX_FILENAME_BYTES = 255


def check_filename_bytes(filename: str) -> None:
    """Reject a generated filename that exceeds the filesystem component limit.

    Measured on the exact final filename string as the exporter writes it -
    sanitised via :func:`clean_label`, with the exporter's prefix and suffix
    included - UTF-8 encoded. A name can be short in characters and still
    overflow in bytes (emoji take up to 4 bytes each), so this must be a
    byte check, never a ``len()`` check. The only caller-controlled portion
    of any generated filename is the bin name, so the message names it.
    Raises ``ValueError`` so the web layer maps it to a clean HTTP 400.
    """
    byte_len = len(filename.encode("utf-8"))
    if byte_len > MAX_FILENAME_BYTES:
        raise ValueError(
            f"bin name produces a {byte_len}-byte filename; the limit is "
            f"{MAX_FILENAME_BYTES} bytes including the export prefix/suffix"
        )
