"""Cradle feature defaults and geometry."""
from __future__ import annotations
import math
import trimesh
from organizer_engine import BoxSpec
from organizer_geometry import difference, union
from ._core import Feature, _fit_count, _need_item
from ._registry import (
    OptionDefinition, SettingInteraction, defaults, feature,
    register_setting_interactions, resolved_options,
)
RIB_THICKNESS = 1.6
CRADLE_RIB_FRACTION = 0.25
CRADLE_RIB_MAX = 6.0
CRADLE_FLOOR_GAP = 2.0
CRADLE_MIN_FLOOR_GAP = 0.4
CRADLE_ALTERNATE_END_MARGIN = 0.10
CRADLE_ALTERNATE_END_MARGIN_MAX = 0.45
CRADLE_RUN_OFFSET_MAX = 1.0
MAX_NOTCH_FRACTION = 0.5

def _cradle_end_margin(one: "Feature") -> float:
    """Alternate-ends clearance kept at each run-axis end, as a fraction of the
    run.

    Stored as a percent in ``options['end_margin']`` - the editor's "% from
    ends" field, which only appears once Alternate ends is on. Missing, blank or
    unparseable falls back to the historic 10%. Clamped to
    ``CRADLE_ALTERNATE_END_MARGIN_MAX`` so the two end margins can never eat the
    whole run.
    """
    raw = one.options.get("end_margin")
    if raw is None or raw == "":
        return CRADLE_ALTERNATE_END_MARGIN
    try:
        fraction = float(raw) / 100.0
    except (TypeError, ValueError):
        return CRADLE_ALTERNATE_END_MARGIN
    if not math.isfinite(fraction):
        return CRADLE_ALTERNATE_END_MARGIN
    return min(max(fraction, 0.0), CRADLE_ALTERNATE_END_MARGIN_MAX)


def _cradle_offset(one: "Feature") -> float:
    """Run-axis slide of a non-alternating cradle, as a signed fraction of the
    slack between the tool and its zone ends.

    Stored as a percent in ``options['run_offset']`` - the editor's "Offset from
    center" field. 0 (or missing / blank / unparseable) keeps the trough
    centred; +100 slides it until its end meets one zone wall, -100 the other
    way. Ignored while ``alternate_ends`` is on.
    """
    raw = one.options.get("run_offset")
    if raw is None or raw == "":
        return 0.0
    try:
        fraction = float(raw) / 100.0
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(fraction):
        return 0.0
    return min(max(fraction, -CRADLE_RUN_OFFSET_MAX), CRADLE_RUN_OFFSET_MAX)


def _cradle_wall(held: float) -> float:
    """The trough wall sized to the tool it carries.

    A thin driver shaft gets the thinnest printable wall; a fat handle gets a
    proportionally chunkier one, capped so a big tool does not grow a slab.
    Not a user setting - there is nothing to tune here that the tool diameter
    does not already decide. Split half to each side of the channel.
    """
    return min(max(held * CRADLE_RIB_FRACTION, RIB_THICKNESS), CRADLE_RIB_MAX)


# kept for callers that still import the old name (organizer_app, tests)
_cradle_rib_thickness = _cradle_wall


@defaults("cradle")
def cradle_defaults(box: BoxSpec, one: "Feature", base_z: float) -> dict[str, float]:
    item = _need_item(one)
    return {
        "rib_thickness": _cradle_wall(item.widest),
        # 0 = neighbouring side walls fully overlap, so the joint is no
        # thicker than either exposed outer side. Raising it first separates
        # those overlapping walls, then opens a real gap.
        "spacing": 0.0,
        "floor_gap": CRADLE_FLOOR_GAP,
        # The editor's one "% from end / Offset from center" field writes to
        # whichever of these matches the Alternate ends state; the other keeps
        # its own last value. Percentages.
        "end_margin": CRADLE_ALTERNATE_END_MARGIN * 100.0,
        "run_offset": 0.0,
    }


def _cradle_seat_plan(box: BoxSpec, spec_feature: Feature, base_z: float) -> dict:
    """The builder and preview share one trough seat/offset calculation."""
    item = _need_item(spec_feature)
    zone = spec_feature.zone
    along = spec_feature.along
    options = resolved_options(box, spec_feature, base_z)
    if along not in {"x", "y"}:
        raise ValueError("cradle orientation must be 'x' or 'y'")

    wall = options["rib_thickness"]
    spacing = options["spacing"]
    # The trough always begins 2 mm above the base. This is deliberately not
    # a user setting, including for older saved designs that stored a value.
    floor_gap = CRADLE_FLOOR_GAP
    if not math.isfinite(spacing) or spacing < 0.0:
        raise ValueError("cradle spacing must be zero or greater")

    length = item.length
    # A cradle is an open half-circle the tool simply drops into, so it takes
    # the tool at its true diameter - no fit slack, nothing to tune.
    held = item.widest
    radius = held / 2.0
    axis_z = base_z + floor_gap + held / 2.0
    trough_height = axis_z - base_z
    run = zone.width if along == "x" else zone.depth
    across = zone.depth if along == "x" else zone.width

    # A trough's wall is split half to each side. At zero spacing its facing
    # halves occupy the same space: the middle joint is one side-wall thick,
    # exactly matching either exposed outside edge rather than becoming 2x.
    side_wall = wall / 2.0
    body = held + wall            # one trough, wall split to either side
    pitch = held + side_wall + spacing
    count = spec_feature.count
    if count is None:
        count = _fit_count(across, pitch, body)
    if count < 1:
        raise ValueError(
            f"No room for this Cradle: {item.name}: {across:.1f} mm across needs at least "
            f"{body:.1f} mm"
        )
    used = (count - 1) * pitch + body
    if used > across + 1e-9:
        raise ValueError(
            f"This Cradle needs {used:.1f} mm across for {count} × {item.name}, "
            f"but this bin gives {across:.1f} mm inside — make the bin wider, "
            "or choose a smaller item."
        )

    alternating = bool(spec_feature.alternate_ends) and count > 1
    end_margin = _cradle_end_margin(spec_feature)
    minimum_alternate_run = length / (1.0 - 2.0 * end_margin)
    if alternating and run + 1e-9 < minimum_alternate_run:
        raise ValueError(
            f"{item.name} in this Cradle is {length:g} mm long and, laid in "
            f"alternating directions, needs {minimum_alternate_run:.1f} mm with the "
            f"ends kept clear, but this bin gives {run:.1f} mm — make the bin "
            "longer, or turn off alternating ends."
        )
    if not alternating and length > run + 1e-9:
        side = "left to right" if along == "x" else "front to back"
        raise ValueError(
            f"{item.name} in this Cradle is {length:g} mm long, but this bin gives "
            f"only {run:.1f} mm inside {side} — make the bin longer {side}, "
            "or choose a shorter item."
        )

    centre_along, centre_across = zone.centre
    if along != "x":
        centre_along, centre_across = centre_across, centre_along
    first = centre_across - (count - 1) * pitch / 2.0
    seats = [first + index * pitch for index in range(count)]

    # A non-alternating row can be slid bodily along the run; the slide is a
    # fraction of the slack between the tool and the zone ends, so it can never
    # push a trough past a wall.
    offset_shift = (
        0.0 if alternating
        else _cradle_offset(spec_feature) * max(0.0, (run - length) / 2.0)
    )

    alternate_shift = ((run - length) / 2.0 - end_margin * run if alternating else 0.0)
    return {
        "item": item, "along": along, "radius": radius, "axis_z": axis_z,
        "length": length, "trough_height": trough_height, "body": body,
        "count": count, "alternating": alternating, "spacing": spacing,
        "side_wall": side_wall, "centre_along": centre_along,
        "centre_across": centre_across, "used": used, "seats": seats,
        "offset_shift": offset_shift, "alternate_shift": alternate_shift,
    }


def cradle_reference_meshes(box: BoxSpec, one: Feature, base_z: float) -> list[trimesh.Trimesh]:
    """Physical tool segments resting in the exact trough seats."""
    plan = _cradle_seat_plan(box, one, base_z)
    item, along = plan["item"], plan["along"]
    meshes = []
    for index, seat in enumerate(plan["seats"]):
        shift = ((plan["alternate_shift"] if index % 2 else -plan["alternate_shift"])
                 if plan["alternating"] else plan["offset_shift"])
        run = -item.length / 2.0
        segments = tuple(reversed(item.segments)) if plan["alternating"] and index % 2 else item.segments
        for segment in segments:
            mesh = trimesh.creation.cylinder(radius=segment.diameter / 2.0,
                                              height=segment.length, sections=48)
            mesh.apply_transform(trimesh.transformations.rotation_matrix(
                math.pi / 2.0, (0, 1, 0) if along == "x" else (1, 0, 0)))
            offset = run + segment.length / 2.0
            mesh.apply_translation((plan["centre_along"] + shift + offset, seat, plan["axis_z"])
                                   if along == "x" else
                                   (seat, plan["centre_along"] + shift + offset, plan["axis_z"]))
            meshes.append(mesh)
            run += segment.length
    return meshes


@feature(
    "cradle", title="Cradle", display="Cradle — tools laid down",
    description="A half-circle notch that holds a tool on its side.",
    capabilities=("qty", "along", "item", "alternate"),
    item_profiles=("round",),  # a cradle is a half-round notch; it never offers Bore's shapes
    options=(
        OptionDefinition("Spacing", "spacing", "0", minimum=0.0, note="mm of clear air between neighbouring troughs; 0 = touching"),
        # Legacy: still tolerated in saved data, but the geometry always uses the
        # fixed CRADLE_FLOOR_GAP, so it is not an editor control.
        OptionDefinition("Floor gap", "floor_gap", "2", editor=False, legacy=True, minimum=CRADLE_MIN_FLOOR_GAP, note="always the fixed floor gap; not a current control"),
        OptionDefinition("% from ends", "end_margin", "10", minimum=0.0, maximum=CRADLE_ALTERNATE_END_MARGIN_MAX * 100.0, note="percent of the run kept clear at each end (used with alternate ends)"),
        OptionDefinition("Offset from center", "run_offset", "0", editor=False, minimum=-CRADLE_RUN_OFFSET_MAX * 100.0, maximum=CRADLE_RUN_OFFSET_MAX * 100.0, note="percent shift of the row along its run"),
        OptionDefinition("Rib thickness", "rib_thickness", "", editor=False, legacy=True, maximum=CRADLE_RIB_MAX, note="always worked out from the held item; not a current control"),
    ), order=10,
)
def build_cradle(box: BoxSpec, spec_feature: Feature, base_z: float) -> list[trimesh.Trimesh]:
    """Half-round troughs holding a tool lying along X or Y.

    Each tool beds into a block the length of the tool with a half-cylinder
    channel cut the whole way along its top - the entire tool, shaft and
    handle, in one continuous channel rather than balancing on two ribs. The
    channel's mouth sits on the block's top face, so the tool drops straight
    in and no layer overhangs the one below it.

    ``spacing`` sets how a row of troughs relates:

    * ``0`` - neighbours join into **one continuous body**. Their facing side
      walls fully overlap, so the joint is no thicker than an exposed side.
    * up to half a wall thickness - still one body, while the shared joint
      widens from one side-wall thickness to two.
    * beyond that - each trough is its **own** solid, with the remaining
      ``spacing`` opening as clear air between them.

    ``alternate_ends`` places every second trough near the opposite end of the
    run axis, leaving ``options['end_margin']`` percent (default ten) of that
    axis clear at each end. With ``alternate_ends`` off, ``options['run_offset']``
    percent slides every trough together along the run - signed, 0 centres them,
    +/-100 pushes a trough edge to a zone wall.
    """
    plan = _cradle_seat_plan(box, spec_feature, base_z)
    along, radius, axis_z, length = (plan[key] for key in ("along", "radius", "axis_z", "length"))
    trough_height, body, count, alternating = (plan[key] for key in
                                                ("trough_height", "body", "count", "alternating"))
    spacing, side_wall, centre_along, centre_across = (plan[key] for key in
                                                       ("spacing", "side_wall", "centre_along", "centre_across"))
    used, seats, offset_shift, alternate_shift = (plan[key] for key in
                                                  ("used", "seats", "offset_shift", "alternate_shift"))

    def _channel(seat: float, shift: float) -> trimesh.Trimesh:
        cut = trimesh.creation.cylinder(
            radius=radius, height=length + 2.0, sections=48
        )
        cut.apply_transform(
            trimesh.transformations.rotation_matrix(
                math.pi / 2.0, (0, 1, 0) if along == "x" else (1, 0, 0)
            )
        )
        cut.apply_translation(
            (centre_along + shift, seat, axis_z) if along == "x"
            else (seat, centre_along + shift, axis_z)
        )
        return cut

    def _body(block_seat: float, block_across: float,
              channel_seats: list[float], shift: float) -> trimesh.Trimesh:
        block = trimesh.creation.box(
            extents=(
                length if along == "x" else block_across,
                block_across if along == "x" else length,
                trough_height,
            )
        )
        block.apply_translation(
            (centre_along + shift, block_seat, base_z + trough_height / 2.0)
            if along == "x"
            else (block_seat, centre_along + shift, base_z + trough_height / 2.0)
        )
        cuts = [_channel(seat, shift) for seat in channel_seats]
        return difference(
            [block, union(cuts) if len(cuts) > 1 else cuts[0]]
        )

    # Neighbours whose blocks touch or overlap (spacing up to one side wall)
    # come out as one continuous body; wider spacing splits them apart.
    if count > 1 and not alternating and spacing <= side_wall + 1e-9:
        _wj_solids = [_body(centre_across, used, seats, offset_shift)]
        from ._walljoin import (
            _join_tabs, _tab_meshes, _footprint_from_solids, _joined_sides,
        )
        from ._bore._consts import JOIN_BAND, WALL_JOIN_FLAG
        from shapely.geometry import box as shapely_box
        from shapely.ops import unary_union
        if spec_feature.options.get(WALL_JOIN_FLAG):
            # Fuse the continuous cradle body into any side wall it reaches.
            # Keep-clear: the plan-view channel mouths (same as Change 3).
            # (alternating is False here, so shift is offset_shift for all.)
            _wj_material = _footprint_from_solids(_wj_solids)
            _wj_channels = []
            for seat in seats:
                _cx0 = centre_along + offset_shift - (length + 2.0) / 2.0
                _cx1 = centre_along + offset_shift + (length + 2.0) / 2.0
                _cy0, _cy1 = seat - radius, seat + radius
                if along == "x":
                    _wj_channels.append(shapely_box(_cx0, _cy0, _cx1, _cy1))
                else:
                    _wj_channels.append(shapely_box(_cy0, _cx0, _cy1, _cx1))
            _wj_keep_clear = unary_union(_wj_channels)
            _wj_tabs = _join_tabs(
                box, _wj_material, _wj_keep_clear, JOIN_BAND,
                sides=_joined_sides(box, _wj_material, "cradle", along),
            )
            _wj_solids.extend(_tab_meshes(_wj_tabs, trough_height, base_z))
        return _wj_solids

    solids: list[trimesh.Trimesh] = []
    for index, seat in enumerate(seats):
        shift = (
            (alternate_shift if index % 2 else -alternate_shift)
            if alternating else offset_shift
        )
        solids.append(_body(seat, body, [seat], shift))
    from ._walljoin import (
        _join_tabs, _tab_meshes, _footprint_from_solids, _joined_sides,
    )
    from ._bore._consts import JOIN_BAND, WALL_JOIN_FLAG
    from shapely.geometry import box as shapely_box
    from shapely.ops import unary_union
    if spec_feature.options.get(WALL_JOIN_FLAG):
        # Fuse the cradle rails into any side wall they reach.
        # Keep-clear: the plan-view channel mouths. Each trough's half-cylinder
        # channel (radius, length+2.0) is open through the block's top and ends;
        # a tab at the block edge would otherwise plug the channel mouth and
        # stop the tool seating. The channel rectangles are built from the
        # seat plan (seat, shift, centre_along, length, radius, along).
        # NOTE: the continuous-body early-return path above also gets tabs (Change 3b).
        _wj_material = _footprint_from_solids(solids)
        _wj_channels = []
        for index, seat in enumerate(seats):
            shift = (
                (alternate_shift if index % 2 else -alternate_shift)
                if alternating else offset_shift
            )
            _cx0 = centre_along + shift - (length + 2.0) / 2.0
            _cx1 = centre_along + shift + (length + 2.0) / 2.0
            _cy0, _cy1 = seat - radius, seat + radius
            if along == "x":
                _wj_channels.append(shapely_box(_cx0, _cy0, _cx1, _cy1))
            else:
                _wj_channels.append(shapely_box(_cy0, _cx0, _cy1, _cx1))
        _wj_keep_clear = unary_union(_wj_channels)
        _wj_tabs = _join_tabs(
            box, _wj_material, _wj_keep_clear, JOIN_BAND,
            sides=_joined_sides(box, _wj_material, "cradle", along),
        )
        solids.extend(_tab_meshes(_wj_tabs, trough_height, base_z))
    return solids


def cradle_min_footprint(one: Feature) -> tuple[float, float]:
    """The smallest ``(width, depth)`` a cradle needs for its tool, count and
    spacing - regardless of what its zone has been clamped to. Mirrors the
    sizing in :func:`build_cradle`; used to grow a bin to fit its contents.
    """
    item = _need_item(one)
    wall = _cradle_wall(item.widest)
    try:
        spacing = float(one.options.get("spacing", 0.0))
    except (TypeError, ValueError) as error:
        raise ValueError("cradle spacing must be zero or greater") from error
    if not math.isfinite(spacing) or spacing < 0.0:
        raise ValueError("cradle spacing must be zero or greater")
    body = item.widest + wall
    pitch = item.widest + wall / 2.0 + spacing
    if one.count is None:
        across_now = one.zone.depth if one.along == "x" else one.zone.width
        count = max(1, _fit_count(across_now, pitch, body))
    else:
        count = max(1, int(round(one.count)))
    length = item.length
    alternating = bool(one.alternate_ends) and count > 1
    run = math.ceil(
        length / (1.0 - 2.0 * _cradle_end_margin(one))
        if alternating else length
    )
    across = math.ceil((count - 1) * pitch + body)
    return (float(run), float(across)) if one.along == "x" else (float(across), float(run))


register_setting_interactions("cradle", (
    SettingInteraction("item.length", "zone.run", "auto-adjust", "cradle-sizing",
                       "Tool length grows the run; a hand-sized run is never shrunk."),
    SettingInteraction("item.diameter", "zone.across", "auto-adjust", "cradle-sizing",
                       "Tool diameter and generated wall grow the Cradle width."),
    SettingInteraction("count", "zone.across", "auto-adjust", "cradle-sizing",
                       "Quantity grows the cross-axis footprint for all troughs."),
    SettingInteraction("spacing", "zone.across", "auto-adjust", "cradle-sizing",
                       "Spacing grows the footprint without shrinking manual size."),
    SettingInteraction("alternate_ends", "end_margin", "enable/disable", "cradle-editor",
                       "Alternate ends shows end clearance and uses it for sizing."),
    SettingInteraction("alternate_ends", "run_offset", "enable/disable", "cradle-editor",
                       "Run offset applies only while Alternate ends is off."),
    SettingInteraction("end_margin", "zone.run", "auto-adjust", "cradle-sizing",
                       "Alternate-end clearance can grow the required run length."),
))
