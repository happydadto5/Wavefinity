"""Feature building, insert assembly, text coordination, and reports."""

from __future__ import annotations

import math
from dataclasses import replace
from typing import Iterable

import manifold3d
import numpy as np
import trimesh
from shapely.geometry import Polygon, box as shapely_box

from organizer_geometry import _extrude_polygon, difference, intersection, union

from organizer_engine import (
    BoxSpec,
    LOCK_PROTRUSION,
    TOP_LABEL_CAP_HEIGHT,
    _rounded,
    direct_stack_enabled,
    flat_cavity_polygon,
    label_placement,
    lid_enabled,
    lid_has_flip,
    top_label_surface_z,
    wavy_cavity_polygon,
)
from organizer_engine._lift_grabbers import make_lift_grabbers

from ._core import (
    BASE_PLATE,
    CARTRIDGE_PITCH,
    INSERT_CLEARANCE,
    Feature,
    Zone,
    cartridge_zone,
    connector_keep_out,
    feature_touches_wall,
    layout_zone,
)
from ._bore import (
    JOIN_STYLES, WALL_HUG_FLAG, WALL_JOIN_FLAG, bore_xy_size_mode, is_walls_only,
    normalize_bore_style,
)
from ._layout import _feature_reach, check_layout, feature_footprint
from ._registry import FEATURE_BUILDERS
from ._text import (
    _oriented_text,
    build_text,
    is_text,
    text_is_raised,
    text_of,
    text_placed_outline,
)
from ._divider import divider_division_texts, divider_labels_present
from ._nest import build_recessed_nest_group, resolve_nest_settings

# Physical assembly policy, not a user-facing capability: only these feature
# kinds may legitimately rise above the bin rim, and only when fused directly
# into the bin with no stacking interface or lid to collide with. A shallow
# vanity-style bin still needs its wall height to mean wall height - it is the
# *interior* geometry of these specific holders that is allowed to be taller.
_FUSED_ABOVE_RIM_KINDS = frozenset({
    "cradle",
    "bore",
    "post",
    "pocket",
    "slot",
    "steps",
})


def _allows_above_rim(one: Feature, mode: str) -> bool:
    if mode != "fused":
        return False
    if one.kind == "nest":
        return (
            one.contour is not None
            and str(one.options.get("holder_style", "raised_wall")).lower()
                == "raised_wall"
        )
    return one.kind in _FUSED_ABOVE_RIM_KINDS


def _nest_recessed_deck_footprint(box: BoxSpec, mode: str) -> Polygon:
    """Physical area a Recessed Photo Nest deck should fill."""
    if mode == "fused":
        return (
            flat_cavity_polygon(box)
            if box.flat_inside > 0.0
            else wavy_cavity_polygon(box)
        )
    if mode == "separate":
        return insert_footprint(box, "separate")
    if mode == "cartridge":
        return insert_footprint(box, "cartridge")
    raise ValueError(f"unknown layout mode {mode!r}")


def build_features(
    box: BoxSpec, features: Iterable[Feature], base_z: float,
    bounds: Zone | None = None, mode: str = "fused",
    include_text: bool = False, grid: str = "wavefinity",
) -> list[trimesh.Trimesh]:
    """:func:`_build_features` with the design ``grid`` known to wall joins."""
    from ._walljoin import BUILD_GRID
    token = BUILD_GRID.set(grid)
    try:
        return _build_features(box, features, base_z, bounds, mode, include_text)
    finally:
        BUILD_GRID.reset(token)


def _build_features(
    box: BoxSpec, features: Iterable[Feature], base_z: float,
    bounds: Zone | None = None, mode: str = "fused",
    include_text: bool = False,
) -> list[trimesh.Trimesh]:
    """Every holder's solids, ready to be added to the body.

    Text is built too - so a bad one reports its error alongside every other
    feature's - but left out of the returned solids unless ``include_text`` is
    set, because a recessed text has to be subtracted from the body rather
    than added to it. The exporter collects it through :func:`build_texts`;
    the preview asks for it here so it can draw it in place.
    """
    from organizer_features.stack import (
        STACK_INTERIOR_MARGIN, STACK_PLUG_DEPTH, STACK_SKIRT_DEPTH, stack_enabled,
    )

    features = list(features)
    check_layout(box, features, bounds, base_z, mode)
    max_feature_z = box.z
    if stack_enabled(box):
        max_feature_z = box.z - STACK_PLUG_DEPTH
    if lid_enabled(box) and not direct_stack_enabled(box):
        # Regular lids close with a shallow skirt; a hinged lid has no skirt but keeps its plug depth.
        lid_depth = STACK_PLUG_DEPTH if lid_has_flip(box) else STACK_SKIRT_DEPTH
        max_feature_z = box.z - lid_depth - STACK_INTERIOR_MARGIN
    solids: list[trimesh.Trimesh] = []
    recessed_nests = [
        one for one in features
        if one.kind == "nest" and one.contour
        and str(resolve_nest_settings(box, one, base_z)["holder_style"]) == "recessed"
    ]
    if recessed_nests:
        shared_deck = _nest_recessed_deck_footprint(box, mode)
        made = [build_recessed_nest_group(box, recessed_nests, base_z, shared_deck)]
        shared = made[0]
        epsilon = 0.01
        x0, y0, x1, y1 = shared_deck.bounds
        if (
            shared.bounds[0][0] < x0 - epsilon
            or shared.bounds[1][0] > x1 + epsilon
            or shared.bounds[0][1] < y0 - epsilon
            or shared.bounds[1][1] > y1 + epsilon
        ):
            raise ValueError(
                "a Photo Nest exceeds the shared recessed deck; reduce its size or move it inward"
            )
        top = shared.bounds[1][2]
        if (stack_enabled(box) or lid_enabled(box)) and top > max_feature_z + 1e-6:
            raise ValueError(
                "a Photo Nest rises into the stacking interface; keep interior "
                f"parts below {max_feature_z:.1f} mm, reduce its height, or make the bin taller"
            )
        if not stack_enabled(box) and not lid_enabled(box) and mode != "fused" and top > box.z + 1e-6:
            raise ValueError(
                "a Photo Nest rises above the bin rim; reduce its height or make the bin taller"
            )
        # A shared deck deliberately spans the physical insert/bin footprint,
        # not any one Nest zone.
        solids.extend(made)
    for one in features:
        if one in recessed_nests:
            continue
        recessed_deck_footprint = None
        if mode == "fused" and one.kind == "bore" and (
                (style := normalize_bore_style(
                    one.options.get("bore_style"), one.options.get("wall_style")))
                in JOIN_STYLES or style == "base_straight"):
            # Only a bore fused into the bin can join its wall; removable and
            # cartridge inserts never touch it. Fix 078: Base - Straight Walls
            # is now join-capable too, not just the upright styles.
            joined = {**one.options, WALL_JOIN_FLAG: True}
            if is_walls_only(style) and bore_xy_size_mode(one.options, style) == "bin_to_bore":
                # The bin is sized around it, so the sleeves bridge the rest of
                # the way to the wall on every side.
                joined[WALL_HUG_FLAG] = True
            one = replace(one, options=joined)

        if mode == "fused" and one.kind in (
                "divider", "cradle", "pocket", "post", "scoop", "slot", "steps"):
            # A fused interior part fuses into any side wall it reaches, like a
            # bore. The flag is inert until Fused Walls 3's builders consume
            # it - current consumers (_layout._feature_reach, bore builder)
            # are bore-only. When consumed, the shared _join_tabs reach check
            # (gap <= JOIN_TOUCH) skips walls the part doesn't reach.
            # Removable inserts (separate/cartridge) never get the flag.
            one = replace(one, options={**one.options, WALL_JOIN_FLAG: True})

        if (
            one.kind == "nest"
            and one.contour
            and one.options.get("holder_style") == "recessed"
        ):
            recessed_deck_footprint = _nest_recessed_deck_footprint(box, mode)
            made = FEATURE_BUILDERS[one.kind](
                box,
                one,
                base_z,
                deck_footprint=recessed_deck_footprint,
            )
        else:
            made = FEATURE_BUILDERS[one.kind](box, one, base_z)

        if is_text(one) and one.options.get("level") == "rim":
            from organizer_engine import top_label_zone
            from ._core import Zone
            reach = Zone(*top_label_zone(box, one.options.get("rim_side", "back")).bounds)
        else:
            # The built solids ride along so _feature_reach can grant the
            # wall-join allowance only on the sides the real material
            # actually reaches (Fused Walls 4). GPT requires real material -
            # never the feature's zone as a proxy.
            reach = _feature_reach(box, one, base_z, made)

        if recessed_deck_footprint is not None:
            x0, y0, x1, y1 = recessed_deck_footprint.bounds
            epsilon = 0.01
            reach = Zone(
                float(x0) - epsilon,
                float(y0) - epsilon,
                float(x1) + epsilon,
                float(y1) + epsilon,
            )
        for solid in made:
            if (
                solid.bounds[0][0] < reach.x0 - 1e-5
                or solid.bounds[1][0] > reach.x1 + 1e-5
                or solid.bounds[0][1] < reach.y0 - 1e-5
                or solid.bounds[1][1] > reach.y1 + 1e-5
            ):
                raise ValueError(
                    f"a {one.kind} exceeds its layout zone; reduce its size "
                    "or thickness option"
                )
        for solid in made:
            top = solid.bounds[1][2]
            if stack_enabled(box) or lid_enabled(box):
                if top > max_feature_z + 1e-6:
                    raise ValueError(
                        f"a {one.kind} rises into the stacking interface; keep "
                        f"interior parts below {max_feature_z:.1f} mm, reduce its "
                        "height, or make the bin taller"
                    )
            elif top > box.z + 1e-6 and not _allows_above_rim(one, mode):
                raise ValueError(
                    f"a {one.kind} rises above the bin rim; reduce its height "
                    "or make the bin taller"
                )
        touches_wall = feature_touches_wall(box, one)
        # A Divider's rim-label shelf follows the same near-rim clearance as a
        # Text shelf. It may enter the connector band, but never the stack/lid
        # plug space; ordinary wall-touching features keep the connector rule.
        divider_rim_shelf = (
            one.kind == "divider"
            and str(one.options.get("division_level", "base")).lower() == "rim"
        )
        clears_stack_lid = all(
            solid.bounds[1][2] <= top_label_surface_z(box) + 1e-6
            for solid in made
        )
        if (
            touches_wall
            and not (one.kind == "nest" and one.contour)
            # Fix 034 G1: Auto Height now resolves to a legal height itself
            # (see bore_defaults), so Auto obeys this exactly like manual.
            and any(solid.bounds[1][2] > connector_keep_out(box) + 1e-6 for solid in made)
            and not ((divider_rim_shelf or (is_text(one) and one.options.get("level") == "rim")) and clears_stack_lid)
        ):
            raise ValueError(
                f"a {one.kind} touching the wall must stay below "
                f"{connector_keep_out(box):.1f} mm so a connector can seat"
            )
        if is_text(one) and not include_text:
            continue
        solids.extend(made)
        if include_text and one.kind == "divider":
            for _label, text_solid, raised in divider_division_texts(box, one, base_z):
                if not raised:
                    solids.append(text_solid)
    return solids


def labels_yielding_to_dividers(features: Iterable[Feature]) -> frozenset[int]:
    """Indexes of the bin's own Label parts that divider labels take over from.

    While any divider carries a label, every Label part is ignored (not built,
    not previewed); the stored text stays, so removing the divider labels
    makes the bin's Label apply again.
    """
    features = list(features)
    if not divider_labels_present(features):
        return frozenset()
    return frozenset(i for i, one in enumerate(features) if is_text(one))


def build_texts(
    box: BoxSpec, features: Iterable[Feature], base_z: float,
    limit: Polygon | None = None,
) -> list[tuple[str, trimesh.Trimesh, bool]]:
    """``(what it says, its solid, whether it stands proud)`` for each text part.

    The caller subtracts every recessed solid from the body to cut its pocket,
    leaves the raised ones alone, and writes all of them as their own objects.

    ``limit`` is the surface the lettering has to stay on - a removable
    insert's plate is pulled in from the wall, so text that would hang over
    its edge is refused here rather than quietly clipped mid-letter the way
    trimming a holder to the same outline safely can be.
    """
    made: list[tuple[str, trimesh.Trimesh, bool]] = []
    for one in features:
        if one.kind == "divider":
            for text_label, text_solid, raised in divider_division_texts(box, one, base_z):
                if not raised:      # a rim shelf is body material, not a text object
                    made.append((text_label, text_solid, False))
            continue
        if not is_text(one) or one.options.get("level") == "rim":
            continue
        if limit is not None and not limit.covers(text_placed_outline(one)):
            raise ValueError(
                f"the text '{text_of(one)}' hangs over the edge of the insert "
                "plate; move it further from the wall"
            )
        made.append((text_of(one), build_text(box, one, base_z)[0],
                     text_is_raised(one)))
    return made


def resolve_text_features(
    box: BoxSpec,
    features: Iterable[Feature],
    reserved: Iterable[Polygon] = (),
    base_z: float = 0.0,
    mode: str = "fused",
) -> tuple[Feature, ...]:
    """Resolve legacy auto placement once, then store fixed glyph-derived Text."""
    from organizer_engine import top_label_zone
    from ._text import canonical_text_feature, retargeted_text, rim_text_geometry
    resolved = list(features)
    for index, one in enumerate(resolved):
        if is_text(one) and one.options.get("retarget"):
            fitted = retargeted_text(box, one, mode)
            if fitted.options.get("level") == "rim" and text_of(fitted):
                cap = math.floor(rim_text_geometry(box, fitted)[2])
                if cap <= 0:
                    raise ValueError("rim Label has no room for a printable whole-millimetre letter height")
                fitted = replace(fitted, options={**fitted.options, "cap_height": float(cap)})
            resolved[index] = fitted
            continue
        if is_text(one) and one.options.get("level") == "rim":
            side = str(one.options.get("rim_side") or "back")
            automatic = not one.options.get("text_v2") and one.options.get("cap_height") in (None, "", TOP_LABEL_CAP_HEIGHT)
            fitted = canonical_text_feature(replace(
                one, zone=Zone(*top_label_zone(box, side).bounds)))
            if automatic and text_of(fitted):
                cap = math.floor(rim_text_geometry(box, fitted)[2])
                if cap <= 0:
                    raise ValueError("rim Label has no room for a printable whole-millimetre letter height")
                fitted = replace(fitted, options={**fitted.options, "cap_height": float(cap)})
            resolved[index] = fitted
            continue
        if not is_text(one) or not one.options.get("auto"):
            resolved[index] = canonical_text_feature(one)
            continue
        obstacles = [shape for shape in reserved if not shape.is_empty]
        obstacles.extend(feature_footprint(box, other, base_z).polygon
                         for other_index, other in enumerate(resolved)
                         if other_index != index and not (is_text(other) and other.options.get("level") == "rim"))
        try:
            placement = label_placement(box, text_of(one), obstacles)
            outline = _oriented_text(text_of(one), placement.cap_height,
                                     placement.quarter_turns)
            x0, y0, x1, y1 = outline.bounds
            zone = Zone(x0 + placement.x, y0 + placement.y,
                        x1 + placement.x, y1 + placement.y)
            options = dict(one.options)
            options.update(cap_height=placement.cap_height,
                           quarter_turns=placement.quarter_turns)
            options.pop("auto", None)
            resolved[index] = canonical_text_feature(replace(one, zone=zone, options=options))
        except (ValueError, ZeroDivisionError):
            resolved[index] = canonical_text_feature(one)
    return tuple(resolved)


def insert_footprint(box: BoxSpec, mode: str = "separate") -> Polygon:
    """The floor outline of a standalone insert.

    A removable insert follows the box's real cavity, including its waves, and
    is offset inward by ``INSERT_CLEARANCE`` so it can still slide in and out.
    A box with a flat lower wall band uses that lower profile because the plate
    sits inside the band.  Cartridge inserts retain their reusable rectangular
    cell footprint.

    Both removable modes pull in by ``INSERT_CLEARANCE + LOCK_PROTRUSION``: the
    lock bumps stand proud of the cavity line only in the upper wall band, so a
    removable part's passage has to clear their tips too, on top of its normal
    running clearance.
    """
    passage_clearance = INSERT_CLEARANCE + LOCK_PROTRUSION
    if mode == "separate":
        cavity = (
            flat_cavity_polygon(box)
            if box.flat_inside > 0.0
            else wavy_cavity_polygon(box)
        )
        footprint = cavity.buffer(-passage_clearance)
        if not isinstance(footprint, Polygon) or footprint.is_empty:
            raise ValueError("this bin is too small for a removable insert")
        return footprint
    bounds = layout_zone(box, mode)
    return _rounded(
        shapely_box(
            bounds.x0 + passage_clearance, bounds.y0 + passage_clearance,
            bounds.x1 - passage_clearance, bounds.y1 - passage_clearance,
        ),
        1.0,
    )


def make_insert_plate(box: BoxSpec, mode: str = "separate") -> trimesh.Trimesh:
    """The bare base plate of a standalone insert, sitting on z = 0."""
    return _extrude_polygon(insert_footprint(box, mode), BASE_PLATE)


def make_fitted_insert(
    box: BoxSpec, features: Iterable[Feature]
) -> trimesh.Trimesh:
    """A standalone insert that drops into this bin.

    It gets its own base plate and is pulled in by ``INSERT_CLEARANCE`` all
    round so it actually goes in, which is the cost of being able to lift it
    out and swap it.
    """
    footprint = insert_footprint(box, "separate")
    plate = make_insert_plate(box, "separate")
    # Validate and size holders at their installed height, then lower them by
    # the bin floor thickness so the removable insert still exports on z=0.
    parts = build_features(
        box, features, BASE_PLATE + box.base_thickness, mode="separate"
    )
    for part in parts:
        part.apply_translation((0.0, 0.0, -box.base_thickness))
    body = union([plate] + parts) if parts else plate
    # A holder is built to its zone, which may run right out to the usable
    # rectangle - fine when fused to the box, but a standalone insert has to
    # clear the wall to go in at all. Trimming the assembled solid to the
    # plate's own footprint keeps that true for every holder, including any
    # added later.
    limit = _extrude_polygon(footprint, box.z * 2.0)
    grabbers = make_lift_grabbers(box)
    if grabbers:
        clearance = 0.4
        padding = manifold3d.Manifold.cube((2 * clearance,) * 3, center=True)
        keep_outs = []
        for grabber in grabbers:
            solid = manifold3d.Manifold(manifold3d.Mesh(
                np.asarray(grabber.vertices, dtype=np.float32),
                np.asarray(grabber.faces, dtype=np.uint32),
            ))
            expanded = solid.minkowski_sum(padding).to_mesh()
            keep_out = trimesh.Trimesh(
                vertices=expanded.vert_properties[:, :3],
                faces=expanded.tri_verts, process=False,
            )
            if keep_out.is_empty:
                raise RuntimeError("could not build Inside Grip insert clearance")
            keep_out.apply_translation((0.0, 0.0, -box.base_thickness))
            keep_outs.append(keep_out)
        limit = difference([limit, *keep_outs])
    return intersection([body, limit])


def make_cartridge_insert(
    box: BoxSpec, features: Iterable[Feature]
) -> trimesh.Trimesh:
    """Standalone insert on the optional centred 7 mm cartridge footprint."""
    bounds = cartridge_zone(box)
    footprint = insert_footprint(box, "cartridge")
    plate = make_insert_plate(box, "cartridge")
    parts = build_features(
        box, features, BASE_PLATE + box.base_thickness, bounds, "cartridge"
    )
    for part in parts:
        part.apply_translation((0.0, 0.0, -box.base_thickness))
    body = union([plate] + parts) if parts else plate
    limit = _extrude_polygon(footprint, box.z * 2.0)
    return intersection([body, limit])


def make_fused_box(
    box: BoxSpec, features: Iterable[Feature], box_mesh: trimesh.Trimesh,
    grid: str = "wavefinity",
) -> trimesh.Trimesh:
    """The bin with its holders grown straight out of the floor."""
    parts = build_features(box, features, box.base_thickness, grid=grid)
    if not parts:
        return box_mesh
    return _without_slivers(union([box_mesh, *parts]))


# A fragment this thin and small is a boolean leftover, never printable
# material: it has no volume and fits inside a 2 mm cube.
_SLIVER_VOLUME_MM3 = 0.01
_SLIVER_SIZE_MM = 2.0


def _without_slivers(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    """Drop zero-volume leftover fragments the union can leave where a divider
    meets the wavy wall at the floor line (they are separate "pieces" that make
    an otherwise sound bin fail the one-solid check). Only tiny, volumeless
    fragments go, and only while a real body remains; any other extra piece is
    kept so validation still reports it."""
    pieces = mesh.split(only_watertight=False)
    if len(pieces) < 2:
        return mesh
    keep = [one for one in pieces
            if abs(float(one.volume)) > _SLIVER_VOLUME_MM3
            or float(max(one.extents)) > _SLIVER_SIZE_MM]
    if not keep or len(keep) == len(pieces):
        return mesh
    cleaned = keep[0] if len(keep) == 1 else trimesh.util.concatenate(keep)
    return cleaned if cleaned.is_watertight or not mesh.is_watertight else mesh


def apply_texts(
    body: trimesh.Trimesh,
    texts: Iterable[tuple[str, trimesh.Trimesh, bool]],
) -> trimesh.Trimesh:
    """Cut every recessed text's pocket out of ``body``.

    A raised text stands on the surface and takes nothing away, so it is left
    alone here and simply written as its own object beside the body.
    """
    sunk = [mesh for _label, mesh, raised in texts if not raised]
    if not sunk:
        return body
    pocketed = difference([body, union(sunk) if len(sunk) > 1 else sunk[0]])
    pocketed.remove_unreferenced_vertices()
    pocketed.merge_vertices()
    return pocketed


def insert_report(name: str, features: Iterable[Feature], mesh: trimesh.Trimesh) -> dict:
    features = list(features)
    return {
        "name": name,
        "features": len(features),
        "kinds": sorted({f.kind for f in features}),
        "volume_cc": round(float(mesh.volume) / 1000.0, 3),
        "watertight": bool(mesh.is_watertight),
    }
