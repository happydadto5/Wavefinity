"""Base Trim geometry, splitting, joints, saved design, and export.

A Base Trim is an open-centre perimeter ring around a nominal Wavefinity field.
It deliberately does not use ``BoxSpec``: field X/Y are the child-bin field,
and every physical trim dimension grows outward from that field.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import math
from pathlib import Path

import numpy as np
import trimesh
from shapely import affinity
from shapely.geometry import Polygon, box as polygon_box
from shapely.ops import unary_union

from organizer_app import clean_label, check_filename_bytes
from organizer_engine import (
    BASE_UNIT,
    WAVE_AMPLITUDE,
    WAVE_MATING_GAP,
    export_mesh,
    export_object_groups_3mf,
    mesh_report,
    wavy_rect_outer,
)
from organizer_geometry import (
    _extrude_polygon,
    _loft_cavity,
    difference,
    intersection,
    union,
)
from organizer_engine.product_rules import (
    SURFACE_TRIM_HEIGHTS,
    SURFACE_TRIM_PRESETS,
)


BASE_TRIM_SCHEMA_VERSION = 1

BASE_TRIM_SIZE_PRESETS = (
    *SURFACE_TRIM_PRESETS,
    ("xl", 15.0, "XL"),
    ("xxl", 20.0, "XXL"),
)

BASE_TRIM_DEFAULT_WIDTH = SURFACE_TRIM_HEIGHTS["medium"]
BASE_TRIM_DEFAULT_HEIGHT = SURFACE_TRIM_HEIGHTS["medium"]
BASE_TRIM_MIN_WIDTH = 4.0
BASE_TRIM_MAX_WIDTH = 20.0
BASE_TRIM_MIN_HEIGHT = 4.0
BASE_TRIM_MAX_HEIGHT = 20.0
BASE_TRIM_OUTER_TAPER = 1.0

BASE_TRIM_DEFAULT_BED_X = 256.0
BASE_TRIM_DEFAULT_BED_Y = 256.0
BASE_TRIM_BED_EDGE_MARGIN = 10.0
BASE_TRIM_MAX_FIELD = 1200.0

BASE_TRIM_JOIN_TYPES = ("drop_in",)
BASE_TRIM_DEFAULT_JOIN = "drop_in"
BASE_TRIM_JOIN_LABELS = {"drop_in": "Drop-in dovetail"}
BASE_TRIM_LEGACY_JOIN_TYPES = {"snap", "dovetail", "puzzle"}

BASE_TRIM_JOINT_CLEARANCE = 0.20
BASE_TRIM_JOINT_SKIN = 1.0


@dataclass(frozen=True)
class BaseTrimSpec:
    field_x: float
    field_y: float
    height_mm: float = BASE_TRIM_DEFAULT_HEIGHT
    width_mm: float = BASE_TRIM_DEFAULT_WIDTH
    join_type: str = BASE_TRIM_DEFAULT_JOIN
    bed_x_mm: float = BASE_TRIM_DEFAULT_BED_X
    bed_y_mm: float = BASE_TRIM_DEFAULT_BED_Y

    @property
    def units(self) -> tuple[int, int]:
        return round(self.field_x / BASE_UNIT), round(self.field_y / BASE_UNIT)

    @property
    def effective_bed(self) -> tuple[float, float]:
        reserve = 2.0 * BASE_TRIM_BED_EDGE_MARGIN
        return self.bed_x_mm - reserve, self.bed_y_mm - reserve

    @property
    def inner_half_extents(self) -> tuple[float, float]:
        return (
            self.field_x / 2.0 + WAVE_MATING_GAP / 2.0,
            self.field_y / 2.0 + WAVE_MATING_GAP / 2.0,
        )

    @property
    def outer_bottom_size(self) -> tuple[float, float]:
        inner_x, inner_y = self.inner_half_extents
        return 2.0 * (inner_x + self.width_mm), 2.0 * (inner_y + self.width_mm)

    @property
    def outer_top_size(self) -> tuple[float, float]:
        outer_x, outer_y = self.outer_bottom_size
        inset = 2.0 * BASE_TRIM_OUTER_TAPER
        return outer_x - inset, outer_y - inset


@dataclass(frozen=True)
class BaseTrimSeam:
    side: str
    coordinate: float


@dataclass(frozen=True)
class BaseTrimPiece:
    index: int
    kind: str
    label: str
    clip_bounds: tuple[float, float, float, float] | None
    start_seam: BaseTrimSeam | None = None
    end_seam: BaseTrimSeam | None = None
    clip_regions: tuple[tuple[float, float, float, float], ...] | None = None


def base_trim_enabled(data: dict) -> bool:
    return isinstance(data, dict) and data.get("design_kind") == "base_trim"


def _number(raw: object, label: str) -> float:
    if isinstance(raw, bool):
        raise ValueError(f"{label} must be a number.")
    try:
        value = float(raw)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{label} must be a number.") from error
    if not math.isfinite(value):
        raise ValueError(f"{label} must be a finite number.")
    return value


def base_trim_from_design(data: dict) -> BaseTrimSpec:
    if not isinstance(data, dict):
        raise ValueError("Base Trim design data must be an object.")
    if data.get("design_kind") != "base_trim":
        raise ValueError("This is not a Base Trim design.")
    if data.get("version") != 6:
        raise ValueError("Base Trim designs must use saved-design version 6.")
    raw_box = data.get("box")
    raw_trim = data.get("base_trim")
    if not isinstance(raw_box, dict):
        raise ValueError("Base Trim field dimensions are missing.")
    if not isinstance(raw_trim, dict):
        raise ValueError("Base Trim settings are missing.")
    if raw_trim.get("version") != BASE_TRIM_SCHEMA_VERSION:
        raise ValueError(
            f"Unsupported Base Trim version {raw_trim.get('version')!r}; "
            f"expected {BASE_TRIM_SCHEMA_VERSION}."
        )
    raw_layout = data.get("layout")
    if not isinstance(raw_layout, dict) or (
        raw_layout.get("version") != 1
        or raw_layout.get("mode") != "fused"
        or raw_layout.get("features") != []
    ):
        raise ValueError("Base Trim layout must be the empty fused layout.")
    if "auto_size" in raw_trim and not isinstance(raw_trim["auto_size"], bool):
        raise ValueError("Base Trim auto_size must be true or false.")
    if "part_name" in data and not isinstance(data["part_name"], str):
        raise ValueError("Base Trim name must be text.")
    join_type = str(raw_trim.get("join_type", ""))
    if join_type in BASE_TRIM_LEGACY_JOIN_TYPES:
        join_type = "drop_in"
    spec = BaseTrimSpec(
        field_x=_number(raw_box.get("x"), "Field width"),
        field_y=_number(raw_box.get("y"), "Field length"),
        height_mm=_number(raw_box.get("z"), "Trim height"),
        width_mm=_number(raw_trim.get("width_mm"), "Trim width"),
        join_type=join_type,
        bed_x_mm=_number(raw_trim.get("bed_x_mm"), "Bed X"),
        bed_y_mm=_number(raw_trim.get("bed_y_mm"), "Bed Y"),
    )
    validate_base_trim(spec)
    return spec


def base_trim_design_to_dict(spec: BaseTrimSpec, part_name: str = "") -> dict:
    validate_base_trim(spec)
    return {
        "version": 6,
        "design_kind": "base_trim",
        "box": {"x": spec.field_x, "y": spec.field_y, "z": spec.height_mm},
        "base_trim": {
            "version": BASE_TRIM_SCHEMA_VERSION,
            "width_mm": spec.width_mm,
            "join_type": spec.join_type,
            "bed_x_mm": spec.bed_x_mm,
            "bed_y_mm": spec.bed_y_mm,
            "auto_size": False,
        },
        "part_name": str(part_name or ""),
        "layout": {"version": 1, "mode": "fused", "snap": 1, "features": []},
    }


def _fits(size: tuple[float, float], bed: tuple[float, float]) -> bool:
    x, y = size
    bed_x, bed_y = bed
    return (
        (x <= bed_x + 1e-6 and y <= bed_y + 1e-6)
        or (x <= bed_y + 1e-6 and y <= bed_x + 1e-6)
    )


def _one_piece(spec: BaseTrimSpec) -> bool:
    return _fits(spec.outer_bottom_size, spec.effective_bed)


def _validate_values(spec: BaseTrimSpec) -> None:
    for value, label in (
        (spec.field_x, "Field width"),
        (spec.field_y, "Field length"),
        (spec.width_mm, "Trim width"),
        (spec.height_mm, "Trim height"),
        (spec.bed_x_mm, "Bed X"),
        (spec.bed_y_mm, "Bed Y"),
    ):
        if not math.isfinite(value):
            raise ValueError(f"{label} must be a finite number.")
    for value, label in ((spec.field_x, "Field width"), (spec.field_y, "Field length")):
        if value < BASE_UNIT - 1e-9:
            raise ValueError(f"{label} must be at least one Wavefinity unit ({BASE_UNIT:g} mm).")
        if value > BASE_TRIM_MAX_FIELD + 1e-9:
            raise ValueError(f"{label} cannot exceed {BASE_TRIM_MAX_FIELD:g} mm.")
        units = value / BASE_UNIT
        if not math.isclose(units, round(units), abs_tol=1e-9):
            raise ValueError(
                f"{label} must be a whole {BASE_UNIT:g} mm Wavefinity unit; "
                f"{value:g} mm is not."
            )
    if not BASE_TRIM_MIN_WIDTH <= spec.width_mm <= BASE_TRIM_MAX_WIDTH:
        raise ValueError(
            f"Trim width must be {BASE_TRIM_MIN_WIDTH:g}-{BASE_TRIM_MAX_WIDTH:g} mm."
        )
    if not BASE_TRIM_MIN_HEIGHT <= spec.height_mm <= BASE_TRIM_MAX_HEIGHT:
        raise ValueError(
            f"Trim height must be {BASE_TRIM_MIN_HEIGHT:g}-{BASE_TRIM_MAX_HEIGHT:g} mm."
        )
    for value, label in ((spec.width_mm, "Trim width"), (spec.height_mm, "Trim height")):
        if not math.isclose(value * 2.0, round(value * 2.0), abs_tol=1e-9):
            raise ValueError(f"{label} must change in 0.5 mm steps.")
    if spec.join_type not in BASE_TRIM_JOIN_TYPES:
        raise ValueError("Section joint must be Drop-in dovetail.")
    if spec.bed_x_mm <= 2.0 * BASE_TRIM_BED_EDGE_MARGIN:
        raise ValueError("Bed X must leave a positive printable area after the 10 mm edge clearance.")
    if spec.bed_y_mm <= 2.0 * BASE_TRIM_BED_EDGE_MARGIN:
        raise ValueError("Bed Y must leave a positive printable area after the 10 mm edge clearance.")


def _validate_split_joint(spec: BaseTrimSpec) -> None:
    if _one_piece(spec):
        return
    if _joint_max_profile_width(spec) < 1.6 - 1e-9:
        raise ValueError(
            f"The {spec.width_mm:g} mm-wide Base Trim is too narrow for the drop-in "
            "dovetail joint when the trim is split. Increase Trim size or use a "
            "larger printer bed."
        )


def validate_base_trim(spec: BaseTrimSpec) -> None:
    _validate_values(spec)
    _validate_split_joint(spec)


def base_trim_inner_polygon(spec: BaseTrimSpec) -> Polygon:
    _validate_values(spec)
    half_x, half_y = spec.inner_half_extents
    return wavy_rect_outer(half_x, half_y)


def _outer_loft(spec: BaseTrimSpec) -> trimesh.Trimesh:
    bottom_x, bottom_y = spec.outer_bottom_size
    top_x, top_y = spec.outer_top_size
    rings = [
        np.asarray([
            [-bottom_x / 2.0, -bottom_y / 2.0],
            [bottom_x / 2.0, -bottom_y / 2.0],
            [bottom_x / 2.0, bottom_y / 2.0],
            [-bottom_x / 2.0, bottom_y / 2.0],
        ], dtype=float),
        np.asarray([
            [-top_x / 2.0, -top_y / 2.0],
            [top_x / 2.0, -top_y / 2.0],
            [top_x / 2.0, top_y / 2.0],
            [-top_x / 2.0, top_y / 2.0],
        ], dtype=float),
    ]
    return _loft_cavity(rings, [0.0, spec.height_mm])


def make_base_trim_ring(spec: BaseTrimSpec) -> trimesh.Trimesh:
    validate_base_trim(spec)
    inner = _extrude_polygon(base_trim_inner_polygon(spec), spec.height_mm + 0.2)
    inner.apply_translation((0.0, 0.0, -0.1))
    ring = difference([_outer_loft(spec), inner])
    ring.metadata["wavefinity_preview_kind"] = "base_trim"
    return ring


def _perimeter_point(
    distance: float, outer_x: float, outer_y: float,
) -> tuple[float, float, BaseTrimSeam, tuple[float, float]]:
    """Return a point, seam, and clockwise tangent on the outer perimeter."""
    perimeter = 2.0 * (outer_x + outer_y)
    distance %= perimeter
    half_x, half_y = outer_x / 2.0, outer_y / 2.0
    if distance < outer_x:
        return -half_x + distance, -half_y, BaseTrimSeam("front", -half_x + distance), (1.0, 0.0)
    distance -= outer_x
    if distance < outer_y:
        return half_x, -half_y + distance, BaseTrimSeam("right", -half_y + distance), (0.0, 1.0)
    distance -= outer_y
    if distance < outer_x:
        return half_x - distance, half_y, BaseTrimSeam("back", half_x - distance), (-1.0, 0.0)
    distance -= outer_x
    return -half_x, half_y - distance, BaseTrimSeam("left", half_y - distance), (0.0, -1.0)


def _perimeter_runs(
    start: float, end: float, outer_x: float, outer_y: float,
) -> list[tuple[str, float, float]]:
    """Return exactly the clockwise straight-side runs in one perimeter arc."""
    perimeter = 2.0 * (outer_x + outer_y)
    side_limits = (outer_x, outer_x + outer_y, 2.0 * outer_x + outer_y, perimeter)
    sides = ("front", "right", "back", "left")
    current = start
    runs: list[tuple[str, float, float]] = []
    while current < end - 1e-9:
        local = current % perimeter
        side_index = next(index for index, limit in enumerate(side_limits) if local < limit - 1e-9)
        boundary = current - local + side_limits[side_index]
        stop = min(end, boundary)
        start_point = _perimeter_point(current, outer_x, outer_y)
        end_point = _perimeter_point(stop, outer_x, outer_y)
        coordinate_a = start_point[0] if sides[side_index] in {"front", "back"} else start_point[1]
        coordinate_b = end_point[0] if sides[side_index] in {"front", "back"} else end_point[1]
        runs.append((sides[side_index], min(coordinate_a, coordinate_b), max(coordinate_a, coordinate_b)))
        current = stop
    return runs


def _run_clip_regions(
    runs: list[tuple[str, float, float]], outer_x: float, outer_y: float,
) -> tuple[tuple[float, float, float, float], ...]:
    """Give each requested perimeter run its own half-ring clipping rectangle."""
    half_x, half_y = outer_x / 2.0, outer_y / 2.0
    margin = 1.0
    regions = []
    for side, low, high in runs:
        if side == "front":
            regions.append((low - margin, -half_y - margin, high + margin, margin))
        elif side == "right":
            regions.append((-margin, low - margin, half_x + margin, high + margin))
        elif side == "back":
            regions.append((low - margin, -margin, high + margin, half_y + margin))
        else:
            regions.append((-half_x - margin, low - margin, margin, high + margin))
    return tuple(regions)


def _perimeter_piece(
    start: float, end: float, outer_x: float, outer_y: float,
) -> tuple[
    tuple[float, float, float, float], BaseTrimSeam, BaseTrimSeam,
    tuple[float, float], tuple[tuple[float, float, float, float], ...],
]:
    """Plan one exact contiguous perimeter arc and its tight XY bounds."""
    start_point = _perimeter_point(start, outer_x, outer_y)
    end_point = _perimeter_point(end, outer_x, outer_y)
    runs = _perimeter_runs(start, end, outer_x, outer_y)
    regions = _run_clip_regions(runs, outer_x, outer_y)
    points = [start_point[:2], end_point[:2]]
    for side, low, high in runs:
        if side in {"front", "back"}:
            y = -outer_y / 2.0 if side == "front" else outer_y / 2.0
            points.extend(((low, y), (high, y)))
        else:
            x = outer_x / 2.0 if side == "right" else -outer_x / 2.0
            points.extend(((x, low), (x, high)))
    xs, ys = zip(*points)
    margin = 1.0
    bounds = (min(xs) - margin, min(ys) - margin, max(xs) + margin, max(ys) + margin)
    return bounds, start_point[2], end_point[2], end_point[3], regions


def _planned_piece_fits(
    bounds: tuple[float, float, float, float], tangent: tuple[float, float],
    bed: tuple[float, float], joint_length: float,
) -> bool:
    """Reserve the male key's outward projection before making the mesh."""
    min_x, min_y, max_x, max_y = bounds
    # The one-millimetre clipping margin is not part of the printed ring.
    width = max_x - min_x - 2.0
    depth = max_y - min_y - 2.0
    if tangent[0]:
        width += joint_length
    else:
        depth += joint_length
    return _fits((width, depth), bed)


def _partition_score(
    cuts: list[float], outer_x: float, outer_y: float,
) -> tuple[float, ...]:
    """Prefer cuts on straight runs and as far as possible from corners."""
    perimeter = 2.0 * (outer_x + outer_y)
    corners = (0.0, outer_x, outer_x + outer_y, 2.0 * outer_x + outer_y)
    clearances = [
        min(min(abs(cut - corner), perimeter - abs(cut - corner)) for corner in corners)
        for cut in cuts
    ]
    spans = [cuts[index + 1] - cuts[index] for index in range(len(cuts) - 1)]
    return (min(clearances), min(spans), -max(spans))


def _search_starts(outer_x: float, outer_y: float) -> list[float]:
    """Use independent straight-run seam starts, including corner fallbacks."""
    limits = (0.0, outer_x, outer_x + outer_y, 2.0 * outer_x + outer_y, 2.0 * (outer_x + outer_y))
    result = set(limits[:-1])
    for low, high in zip(limits, limits[1:]):
        for index in range(1, 17):
            result.add(low + (high - low) * index / 17.0)
    return sorted(result)


def _furthest_piece_ends(
    start: float, limit: float, outer_x: float, outer_y: float,
    bed: tuple[float, float], joint_length: float,
) -> list[float]:
    """Find the bed-limit crossing on each following straight run."""
    perimeter = 2.0 * (outer_x + outer_y)
    corners = (0.0, outer_x, outer_x + outer_y, 2.0 * outer_x + outer_y, perimeter)
    ends: list[float] = []
    base = math.floor(start / perimeter) * perimeter
    for corner in corners[1:]:
        boundary = base + corner
        if boundary <= start + 1e-9:
            boundary += perimeter
        if boundary >= limit - 1e-9:
            break
        bounds, _start_seam, _end_seam, tangent, _regions = _perimeter_piece(
            start, boundary, outer_x, outer_y,
        )
        if _planned_piece_fits(bounds, tangent, bed, joint_length):
            ends.append(boundary)
            continue
        low, high = start, boundary
        for _ in range(32):
            middle = (low + high) / 2.0
            bounds, _start_seam, _end_seam, tangent, _regions = _perimeter_piece(
                start, middle, outer_x, outer_y,
            )
            if _planned_piece_fits(bounds, tangent, bed, joint_length):
                low = middle
            else:
                high = middle
        if low > start + 1e-6:
            ends.append(low)
        return ends
    bounds, _start_seam, _end_seam, tangent, _regions = _perimeter_piece(
        start, limit, outer_x, outer_y,
    )
    if _planned_piece_fits(bounds, tangent, bed, joint_length):
        ends.append(limit)
    return ends


def plan_base_trim_pieces(spec: BaseTrimSpec) -> list[BaseTrimPiece]:
    _validate_values(spec)
    _validate_split_joint(spec)
    if _one_piece(spec):
        return [BaseTrimPiece(1, "whole", "Complete Base Trim", None)]

    outer_x, outer_y = spec.outer_bottom_size
    perimeter = 2.0 * (outer_x + outer_y)
    joint_length = _joint_length(spec)
    smallest_bed_side = min(spec.effective_bed)
    if smallest_bed_side <= joint_length + 1e-6:
        raise ValueError("The declared printable area is too small for a Base Trim joint.")
    max_count = max(2, math.ceil(perimeter / (smallest_bed_side - joint_length)) + 4)
    for count in range(2, max_count + 1):
        best: tuple[tuple[float, ...], list[BaseTrimPiece]] | None = None
        for start in _search_starts(outer_x, outer_y):
            target = start + perimeter

            def build(current: float, remaining: int) -> list[float] | None:
                if remaining == 1:
                    bounds, _start_seam, _end_seam, tangent, _regions = _perimeter_piece(
                        current, target, outer_x, outer_y,
                    )
                    return [target] if _planned_piece_fits(bounds, tangent, spec.effective_bed, joint_length) else None
                choices = _furthest_piece_ends(
                    current, target, outer_x, outer_y, spec.effective_bed, joint_length,
                )
                ideal = current + (target - current) / remaining
                bounds, _start_seam, _end_seam, tangent, _regions = _perimeter_piece(
                    current, ideal, outer_x, outer_y,
                )
                if _planned_piece_fits(bounds, tangent, spec.effective_bed, joint_length):
                    choices.append(ideal)
                for end in sorted(set(choices), key=lambda value: abs(value - ideal)):
                    if end >= target - 1e-6:
                        continue
                    rest = build(end, remaining - 1)
                    if rest is not None:
                        return [end, *rest]
                return None

            ends = build(start, count)
            if ends is None:
                continue
            cuts = [start, *ends]
            planned = []
            for index, (piece_start, piece_end) in enumerate(zip(cuts, cuts[1:]), 1):
                bounds, start_seam, end_seam, _tangent, regions = _perimeter_piece(
                    piece_start, piece_end, outer_x, outer_y,
                )
                planned.append(BaseTrimPiece(
                    index, "perimeter", f"Perimeter section {index}", bounds,
                    start_seam, end_seam, regions,
                ))
            score = _partition_score([cut % perimeter for cut in cuts[:-1]], outer_x, outer_y)
            if best is None or score > best[0]:
                best = score, planned
        if best is not None:
            return best[1]
    raise ValueError(
        "The Base Trim cannot be divided into printable perimeter sections for the declared bed. "
        "Increase the printer bed size."
    )


def _seam_frame(
    spec: BaseTrimSpec, seam: BaseTrimSeam,
) -> tuple[tuple[float, float], tuple[float, float], tuple[float, float]]:
    inner_x, inner_y = spec.inner_half_extents
    top_width = spec.width_mm - BASE_TRIM_OUTER_TAPER
    # The inner face swings a full +/- wave across every 3.5 mm seam. Centre the
    # joint in the guaranteed material between the fixed outside face and the
    # most outward inner crest, rather than in the nominal straight band.
    wave_offset = WAVE_AMPLITUDE / 2.0
    if seam.side == "front":
        return (seam.coordinate, -inner_y - top_width / 2.0 - wave_offset), (1.0, 0.0), (0.0, 1.0)
    if seam.side == "right":
        return (inner_x + top_width / 2.0 + wave_offset, seam.coordinate), (0.0, 1.0), (-1.0, 0.0)
    if seam.side == "back":
        return (seam.coordinate, inner_y + top_width / 2.0 + wave_offset), (-1.0, 0.0), (0.0, -1.0)
    return (-inner_x - top_width / 2.0 - wave_offset, seam.coordinate), (0.0, -1.0), (1.0, 0.0)


def _joint_max_profile_width(spec: BaseTrimSpec) -> float:
    """Width left after the wave, female clearance, and both structural skins."""
    safe_width = spec.width_mm - BASE_TRIM_OUTER_TAPER - WAVE_AMPLITUDE
    return safe_width - 2.0 * BASE_TRIM_JOINT_SKIN - 2.0 * BASE_TRIM_JOINT_CLEARANCE


def _joint_scale(spec: BaseTrimSpec) -> float:
    return min(spec.width_mm, spec.height_mm)


def _joint_length(spec: BaseTrimSpec) -> float:
    return 0.55 * _joint_scale(spec)


def _joint_profile(spec: BaseTrimSpec) -> Polygon:
    length = _joint_length(spec)
    max_width = _joint_max_profile_width(spec)
    head = min(0.45 * _joint_scale(spec), max_width)
    neck = 0.70 * head
    if head <= 0 or neck <= 0:
        raise ValueError("Base Trim is too small for the drop-in joint.")
    return Polygon([
        (0.0, -neck / 2.0),
        (length, -head / 2.0),
        (length,  head / 2.0),
        (0.0,  neck / 2.0),
    ])


def _joint_solid(spec: BaseTrimSpec, seam: BaseTrimSeam, female: bool) -> trimesh.Trimesh:
    profile = _joint_profile(spec)
    if female:
        profile = profile.buffer(BASE_TRIM_JOINT_CLEARANCE, join_style=2)
    else:
        # Let every male key overlap its parent section by a small root. A
        # face-only contact at the cut plane is not a dependable printable
        # union, while this does not increase the advertised projection.
        min_x, min_y, _, max_y = profile.bounds
        profile = unary_union([
            profile,
            polygon_box(min_x - 0.25, min_y, min_x + 0.05, max_y),
        ])
    origin, tangent, lateral = _seam_frame(spec, seam)
    world = affinity.affine_transform(
        profile,
        [tangent[0], lateral[0], tangent[1], lateral[1], origin[0], origin[1]],
    )
    # Full-height vertical drop-in: the female slot has no floor or ceiling,
    # so the mating section can be lowered straight down into it.
    if female:
        z0 = -BASE_TRIM_JOINT_CLEARANCE
        height = spec.height_mm + 2.0 * BASE_TRIM_JOINT_CLEARANCE
    else:
        z0 = 0.0
        height = spec.height_mm
    solid = _extrude_polygon(world, height)
    solid.apply_translation((0.0, 0.0, z0))
    return solid


def _piece_clip(spec: BaseTrimSpec, piece: BaseTrimPiece) -> trimesh.Trimesh:
    if not piece.clip_regions:
        raise ValueError("A split Base Trim piece is missing its clipping bounds.")
    profile = unary_union([polygon_box(*region) for region in piece.clip_regions])
    clip = _extrude_polygon(profile, spec.height_mm + 2.0)
    clip.apply_translation((0.0, 0.0, -1.0))
    return clip


def _make_base_trim_piece_meshes(
    spec: BaseTrimSpec, plans: list[BaseTrimPiece], *, enforce_bed: bool = True,
) -> list[tuple[BaseTrimPiece, trimesh.Trimesh]]:
    """Own the shared production mesh sequence for real and test-only pieces.

    1. make the ring; 2. exact clip intersection; 3. union male joint at
    end_seam; 4. subtract female joint at start_seam; 5. metadata; 6. final
    fit check when ``enforce_bed`` is true.
    """
    ring = make_base_trim_ring(spec)
    if len(plans) == 1:
        return [(plans[0], ring)]
    result: list[tuple[BaseTrimPiece, trimesh.Trimesh]] = []
    for piece in plans:
        body = intersection([ring, _piece_clip(spec, piece)])
        if piece.end_seam is not None:
            body = union([body, _joint_solid(spec, piece.end_seam, False)])
        if piece.start_seam is not None:
            body = difference([body, _joint_solid(spec, piece.start_seam, True)])
        body.metadata["wavefinity_preview_kind"] = "base_trim"
        if enforce_bed:
            size = tuple(float(v) for v in (body.bounds[1] - body.bounds[0])[:2])
            if not _fits(size, spec.effective_bed):
                raise ValueError(
                    f"Base Trim part {piece.index} cannot fit the declared printable area. "
                    "Increase the printer bed size."
                )
        result.append((piece, body))
    return result


def make_base_trim_pieces(spec: BaseTrimSpec) -> list[tuple[BaseTrimPiece, trimesh.Trimesh]]:
    validate_base_trim(spec)
    plans = plan_base_trim_pieces(spec)
    return _make_base_trim_piece_meshes(spec, plans)


def base_trim_summary(spec: BaseTrimSpec) -> dict:
    validate_base_trim(spec)
    pieces = plan_base_trim_pieces(spec)
    outer = spec.outer_bottom_size
    outer_top = spec.outer_top_size
    inner_x, inner_y = spec.inner_half_extents
    seams = [] if len(pieces) == 1 else [
        {"side": one.end_seam.side, "coordinate": round(one.end_seam.coordinate, 3)}
        for one in pieces if one.end_seam is not None
    ]
    return {
        "field_mm": [spec.field_x, spec.field_y],
        "field_units": list(spec.units),
        "width_mm": spec.width_mm,
        "height_mm": spec.height_mm,
        "inner_half_mm": [inner_x, inner_y],
        "outer_mm": list(outer),
        "outer_top_mm": list(outer_top),
        "bed_mm": [spec.bed_x_mm, spec.bed_y_mm],
        "effective_bed_mm": list(spec.effective_bed),
        "edge_margin_mm": BASE_TRIM_BED_EDGE_MARGIN,
        "join_type": spec.join_type,
        "join_label": BASE_TRIM_JOIN_LABELS[spec.join_type],
        "piece_count": len(pieces),
        "one_piece": len(pieces) == 1,
        "seams": seams,
        "pieces": [
            {
                "number": one.index,
                "label": one.label,
                "kind": one.kind,
                "clip_bounds": list(one.clip_bounds) if one.clip_bounds else None,
                "clip_regions": [list(region) for region in one.clip_regions] if one.clip_regions else None,
            }
            for one in pieces
        ],
    }


def _dimension_text(value: float) -> str:
    return f"{value:g}"


def _base_filename(spec: BaseTrimSpec, part_name: str = "") -> str:
    units_x, units_y = spec.units
    name = (
        f"Base Trim {_dimension_text(spec.field_x)} x {_dimension_text(spec.field_y)} "
        f"({units_x}U x {units_y}U)"
    )
    tidy = clean_label(part_name)
    if tidy:
        name += f" {tidy}"
    return name


def _piece_filenames(stem: str, total: int) -> list[str]:
    return [
        f"{stem}.3mf" if total == 1 else f"{stem} Part {index:02d} of {total:02d}.3mf"
        for index in range(1, total + 1)
    ]


def base_trim_output_plan(spec: BaseTrimSpec, part_name: str = "") -> list[dict]:
    """The deterministic piece files this Base Trim makes, without building any
    geometry: ``[{number, label, kind, filename}]`` in piece order."""
    validate_base_trim(spec)
    pieces = plan_base_trim_pieces(spec)
    names = _piece_filenames(_base_filename(spec, part_name), len(pieces))
    return [
        {"number": piece.index, "label": piece.label, "kind": piece.kind, "filename": name}
        for piece, name in zip(pieces, names)
    ]


def generate_base_trim_files(
    spec: BaseTrimSpec,
    output_dir: Path,
    part_name: str = "",
    auto_timestamp: bool = False,
) -> dict:
    validate_base_trim(spec)
    made = make_base_trim_pieces(spec)
    output_dir = Path(output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = _base_filename(spec, part_name)
    total = len(made)
    targets = [output_dir / name for name in _piece_filenames(stem, total)]
    if auto_timestamp and (not clean_label(part_name) or any(path.exists() for path in targets)):
        timestamp = datetime.now().strftime("%m%d%y%H%M%S")
        targets = [path.with_name(f"{path.stem} {timestamp}{path.suffix}") for path in targets]
    # Real filename boundary for Base Trim pieces: the piece suffixes
    # (" Part 99 of 99.3mf") and the timestamp branch both add bytes on top
    # of the part-name stem, so every final target is checked, not the stem.
    for target in targets:
        check_filename_bytes(target.name)
    parts = []
    for (plan, mesh), target in zip(made, targets):
        exported = mesh.copy()
        centre = (exported.bounds[0] + exported.bounds[1]) / 2.0
        exported.apply_translation((-centre[0], -centre[1], -exported.bounds[0][2]))
        export_mesh(exported, target, f"base_trim_part_{plan.index:02d}")
        parts.append({
            "number": plan.index,
            "name": plan.label,
            "output": str(target),
            "mesh": mesh_report(f"base_trim_part_{plan.index:02d}", exported),
        })
    return {
        "mode": "base_trim",
        "base_trim": base_trim_summary(spec),
        "output": str(targets[0]) if total == 1 else None,
        "parts": parts,
    }


BASE_TRIM_JOINT_TEST_TARGET_OUTER = 50.0
BASE_TRIM_JOINT_TEST_GAP = 7.0


def make_base_trim_joint_test(
    width_mm: float, height_mm: float, bed_x_mm: float, bed_y_mm: float,
) -> tuple[BaseTrimSpec, list[tuple[BaseTrimPiece, trimesh.Trimesh]]]:
    """Build a real two-piece drop-in-joint sample near a 50 mm outer square.

    Uses the production ring and production joint geometry - never a
    simplified coupon - forced to exactly two pieces so the print exercises
    both a male and a female production seam.
    """
    wanted_field = BASE_TRIM_JOINT_TEST_TARGET_OUTER - WAVE_MATING_GAP - 2.0 * width_mm
    units = max(1, round(wanted_field / BASE_UNIT))
    field = units * BASE_UNIT
    spec = BaseTrimSpec(
        field_x=field, field_y=field, height_mm=height_mm, width_mm=width_mm,
        join_type="drop_in", bed_x_mm=bed_x_mm, bed_y_mm=bed_y_mm,
    )
    validate_base_trim(spec)

    outer_x, outer_y = spec.outer_bottom_size
    perimeter = 2.0 * (outer_x + outer_y)
    start = outer_x / 2.0
    opposite = outer_x + outer_y + outer_x / 2.0
    arcs = (
        (start, opposite, "Base Trim Joint Test A"),
        (opposite, start + perimeter, "Base Trim Joint Test B"),
    )
    plans = []
    for index, (piece_start, piece_end, label) in enumerate(arcs, 1):
        bounds, start_seam, end_seam, _tangent, regions = _perimeter_piece(
            piece_start, piece_end, outer_x, outer_y,
        )
        plans.append(BaseTrimPiece(index, "perimeter", label, bounds, start_seam, end_seam, regions))

    pieces = _make_base_trim_piece_meshes(spec, plans, enforce_bed=False)
    return spec, pieces


def generate_base_trim_joint_test_file(
    spec: BaseTrimSpec,
    output_dir: Path,
    auto_timestamp: bool = False,
) -> dict:
    """Generate the hidden Ctrl+Shift+click physical joint-fit sample.

    One 3MF, two independent top-level Bambu objects, spaced apart in XY so
    they print separately and are never unioned together.
    """
    test_spec, made = make_base_trim_joint_test(
        spec.width_mm, spec.height_mm, spec.bed_x_mm, spec.bed_y_mm,
    )
    output_dir = Path(output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"Base Trim Joint Test {_dimension_text(spec.width_mm)}mm"
    target = output_dir / f"{stem}.3mf"
    if auto_timestamp and target.exists():
        timestamp = datetime.now().strftime("%m%d%y%H%M%S")
        target = target.with_name(f"{target.stem} {timestamp}{target.suffix}")

    placed: list[tuple[BaseTrimPiece, trimesh.Trimesh]] = []
    for piece, mesh in made:
        one = mesh.copy()
        centre = (one.bounds[0] + one.bounds[1]) / 2.0
        one.apply_translation((-centre[0], -centre[1], -one.bounds[0][2]))
        placed.append((piece, one))

    widths = [one.bounds[1][0] - one.bounds[0][0] for _piece, one in placed]
    total_width = sum(widths) + BASE_TRIM_JOINT_TEST_GAP * (len(placed) - 1)
    cursor = -total_width / 2.0
    objects = []
    parts = []
    for (piece, one), width in zip(placed, widths):
        one.apply_translation((cursor + width / 2.0, 0.0, 0.0))
        cursor += width + BASE_TRIM_JOINT_TEST_GAP
        objects.append((piece.label, [(piece.label, one)]))
        parts.append({
            "number": piece.index,
            "name": piece.label,
            "output": str(target),
            "mesh": mesh_report(piece.label, one),
        })

    object_names = export_object_groups_3mf(objects, target)
    return {
        "mode": "base_trim_joint_test",
        "base_trim": base_trim_summary(test_spec),
        "output": str(target),
        "parts": parts,
        "object_names": object_names,
    }
