"""B4B handle geometry."""

from __future__ import annotations

import math
import numpy as np
import trimesh
from shapely.geometry import Point, Polygon
from organizer_engine import WAVE_AMPLITUDE, BoxSpec
from organizer_geometry import (
    _extrude_polygon,
    _extrude_yz_profile,
    difference,
    intersection as _intersection,
    union,
)
from .._constants import (
    B4B_RUNNING_GAP,
    B4B_HW_RELIEF_CLEARANCE,
    B4B_HW_FILLET,
    B4B_HANDLE_EYE_OVERLAP,
    B4B_HANDLE_STOP_FACE,
    B4B_HANDLE_END_CLEARANCE,
    B4B_HANDLE_DETENT_RAMP,
    B4B_HANDLE_EDGE_CHAMFER,
    B4B_HANDLE_EDGE_STEPS,
)
from .._layout import (
    b4b_layout,
    b4b_lid_skin_from_eff,
    b4b_effective_box,
    b4b_lid_underside_z_from_eff,
)
from .._plans import B4BHardwarePlan, _ear_wall_anchor_y, B4BHandlePlan, b4b_handle_plan

from ._cutters import (
    support_free_profile_yz,
    _round_bore,
    _weld,
    _filleted,
    _cavity_prism,
    _handle_fork_positions,
    _root_profile_yz,
    _root_taper_prism,
    _relief_cutter,
    _pivot_section,
    _ear_solid,
    _gusset,
)


# --------------------------------------------------------------------------- #
# folding front handle
# --------------------------------------------------------------------------- #
def _softened_slab(
    outline: Polygon, thickness: float, chamfer: float
) -> trimesh.Trimesh:
    """The bail's section, with its perimeter edge broken back on both faces.

    A carried part should not present a square extruded edge to the hand on
    either side, so both faces are softened and the middle of the band keeps
    its full thickness.  Each bevel is built as short 45-degree treads rather
    than a single draft so every face remains either vertical or flat: the
    treads on the bed side are the 45-degree steps a printer bridges without
    support, and nothing here may introduce any other overhang.
    """
    steps = max(1, B4B_HANDLE_EDGE_STEPS)
    lo, hi = -thickness / 2.0, thickness / 2.0
    chamfer = min(chamfer, thickness / 2.0 - 1e-3)
    layers = [_extrude_polygon(outline, thickness - 2.0 * chamfer)]
    layers[0].apply_translation((0.0, 0.0, lo + chamfer))
    tread = chamfer / steps
    for i in range(1, steps + 1):
        inset = chamfer * i / steps
        ring = outline.buffer(-inset, join_style=1, quad_segs=12)
        if ring.is_empty or not isinstance(ring, Polygon):
            break
        # each tread overlaps the one before it by a hair, always inward, so
        # neither outer face is pushed past the thickness
        for base in (hi - chamfer + (i - 1) * tread - 1e-3, lo + chamfer - i * tread):
            layer = _extrude_polygon(ring, tread + 1e-3)
            layer.apply_translation((0.0, 0.0, base))
            layers.append(layer)
    solid = union(layers) if len(layers) > 1 else layers[0]
    # the stack was built in X/Y/Z; roll it so the outline lands on X/Z and the
    # thickness runs across Y, the way the bail sits on the case
    solid.apply_transform(np.asarray([
        [1.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 1.0, 0.0],
        [0.0, 1.0, 0.0, 0.0],
        [0.0, 0.0, 0.0, 1.0],
    ]))
    return solid


def _handle_centreline(plan: B4BHandlePlan):
    """The U's centreline path, arms plus a real radiused lower corner.

    Each arm's tip runs ``B4B_HANDLE_EYE_OVERLAP`` past the pivot axis rather
    than stopping exactly on it, so the arm and the pivot eye - unioned onto
    it separately in :func:`make_b4b_handle` - genuinely overlap in 3D
    instead of merely touching tangent-to-tangent.
    """
    from shapely.geometry import LineString

    half = plan.pivot_span / 2.0
    grip_z = plan.grip_z
    r = plan.corner_radius
    tip_z = plan.axis_z + B4B_HANDLE_EYE_OVERLAP
    pts = [(-half, tip_z), (-half, grip_z + r)]
    steps = 12
    for i in range(steps + 1):
        a = math.pi + (math.pi / 2.0) * (i / steps)
        pts.append((-half + r + r * math.cos(a), grip_z + r + r * math.sin(a)))
    pts.append((half - r, grip_z))
    for i in range(steps + 1):
        a = -math.pi / 2.0 + (math.pi / 2.0) * (i / steps)
        pts.append((half - r + r * math.cos(a), grip_z + r + r * math.sin(a)))
    pts.append((half, tip_z))
    return LineString(pts)


def b4b_handle_outline(plan: B4BHandlePlan) -> Polygon:
    """X/Z outline of the U's grip/arms: straight arms, broad lower radii,
    straight grip.

    Cross-section is constant through grip and arms and only tapers, near its
    top, from the full band down to the eye band - it stops/tapers *into* the
    pivot zone rather than trying to be the pivot eye itself.  The complete,
    closed eye solid is unioned on separately in :func:`make_b4b_handle`, so
    this outline is never responsible for the round bore's surrounding
    plastic and can never clip it.
    """
    band = plan.band / 2.0
    outline = _handle_centreline(plan).buffer(
        band, cap_style=2, join_style=1, quad_segs=24
    )
    if not isinstance(outline, Polygon) or not outline.is_valid:
        raise RuntimeError("the Storage Box handle outline did not resolve")
    # Taper the band down to the eye width over the top run, so the resolved
    # pivot stack fits without thinning the part a hand actually holds.  The
    # taper is symmetric about each arm's own centreline - narrowing only the
    # outer edges would leave the inner face full width and drive the arm
    # straight into the fork's thread-forming lug.
    half = plan.pivot_span / 2.0
    eye = plan.eye_band / 2.0
    tip_z = plan.axis_z + B4B_HANDLE_EYE_OVERLAP
    z_hi = tip_z + 0.5
    z_lo = plan.axis_z - plan.taper_run
    keeper = Polygon([
        (-half - band, -1e4), (half + band, -1e4),
        (half + band, z_lo), (-half - band, z_lo),
    ])
    # The body ears (barrel plus fillet) stand a running gap off the eye band,
    # and the arm swings past them at the carry stop, so the band must stay at
    # eye width until it is clear of the ear before it widens.
    z_hold = max(z_lo, plan.axis_z - (plan.profile.pivot_radius + B4B_HW_FILLET))
    for cx in plan.centers_x:
        keeper = keeper.union(Polygon([
            (cx - band, z_lo), (cx + band, z_lo),
            (cx + eye, z_hold), (cx + eye, z_hi),
            (cx - eye, z_hi), (cx - eye, z_hold),
        ]))
    trimmed = outline.intersection(keeper)
    if isinstance(trimmed, Polygon) and trimmed.is_valid and not trimmed.is_empty:
        outline = trimmed
    # The trim can leave a near-zero edge where the taper meets the buffered
    # arm (2.7e-14 mm on a 63 mm case); extruded, that edge leaves the slab
    # open and the union refuses it.  Drop such vertices; 1e-6 mm moves nothing.
    cleaned = outline.simplify(1e-6, preserve_topology=True)
    if isinstance(cleaned, Polygon) and cleaned.is_valid and not cleaned.is_empty:
        outline = cleaned
    return outline


def _handle_end_radius(plan: B4BHandlePlan) -> float:
    """Reach of the arm ends' non-contact envelope at the carry stop.

    The plan's ``heel_radius`` leaves only the running gap to the wall crest;
    the ends are relieved back to ``B4B_HANDLE_END_CLEARANCE`` so print growth
    cannot close it.  Only the datums of the ends move - the eye, axis, rest
    pose and detents are computed from the plan and are untouched.
    """
    reach = plan.front_crest - plan.axis_y - B4B_HANDLE_END_CLEARANCE - 0.01
    return max(plan.eye_radius, min(plan.heel_radius, reach))


def make_b4b_handle(box: BoxSpec) -> trimesh.Trimesh | None:
    """The folding bail, in assembly space, shown stowed against the front wall.

    One flat-printed U.  The grip/arms are extruded from the outline through
    the handle thickness; at each pivot a *complete*, separately-built closed
    eye - the same support-free section every other B4B barrel uses - is
    unioned onto the arm with real 3D overlap.  The round clearance bore is
    only cut once every solid (arms, eyes, carry-stop heels) is unioned into
    one piece, so the bore can never be clipped down to a partial C-shape by
    an earlier intersection - it is always subtracted from finished plastic
    that already fully surrounds it.
    """
    plan = b4b_handle_plan(box)
    if plan is None:
        return None
    outline = b4b_handle_outline(plan)
    slab = _softened_slab(outline, plan.thickness, B4B_HANDLE_EDGE_CHAMFER)
    slab.apply_translation((0.0, plan.axis_y, 0.0))
    # The square tips above the axis used to sweep farther than the eye.
    # Clip only that end; the lower U and its stow pockets are untouched.
    reach = plan.drop + plan.band + 10.0
    lower = trimesh.creation.box(extents=(2.0 * reach + plan.pivot_span, 2.0 * reach, reach))
    lower.apply_translation((0.0, plan.axis_y, plan.axis_z - reach / 2.0))
    keepers = [lower]
    for cx in plan.centers_x:
        end = _extrude_yz_profile(
            Point(plan.axis_y, plan.axis_z).buffer(
                _handle_end_radius(plan), quad_segs=48
            ),
            plan.band,
        )
        end.apply_translation((cx, 0.0, 0.0))
        keepers.append(end)
    slab = _intersection([slab, union(keepers)])

    eyes: list[trimesh.Trimesh] = []
    stops: list[trimesh.Trimesh] = []
    bores: list[trimesh.Trimesh] = []
    pockets: list[trimesh.Trimesh] = []
    for cx in plan.centers_x:
        eye = _extrude_yz_profile(
            support_free_profile_yz(plan.eye_radius), plan.eye_band
        )
        eye.apply_translation((cx, plan.axis_y, plan.axis_z))
        eyes.append(eye)
        stops.append(_handle_stop_heel(plan, cx))
        bore = _round_bore(plan.profile.clear_bore / 2.0, plan.eye_band + 2.0)
        bore.apply_translation((cx, plan.axis_y, plan.axis_z))
        bores.append(bore)
    for cx in plan.detent_centers_x:
        depth = max(0.05, plan.detent_bump - plan.detent_interference)
        pocket = trimesh.creation.box(
            extents=(plan.band * 0.7, 2.0 * depth, 3.0)
        )
        pocket.apply_translation(
            (cx, plan.axis_y + plan.eye_radius, plan.detent_pocket_z)
        )
        pockets.append(pocket)
    # The bail prints with its wall-facing (+Y) side on the bed.  The eye
    # barrels stand proud of the band on that side and would hold the whole
    # part off the plate, so their bed side is cut flush with the band's bed
    # face; the bore, axis and the eyes' other side are untouched.
    bed_y = plan.axis_y + plan.thickness / 2.0
    reach = plan.band + 4.0 * plan.eye_radius
    bed_clip = trimesh.creation.box(extents=(
        2.0 * (abs(plan.centers_x[0]) + plan.band + 4.0), reach,
        4.0 * (plan.eye_radius + plan.band) + 2.0 * plan.drop,
    ))
    bed_clip.apply_translation((0.0, bed_y - reach / 2.0, plan.axis_z))
    eyes = [_intersection([e, bed_clip]) for e in eyes]
    stops = [_intersection([st, bed_clip]) for st in stops]
    handle = union([slab, *eyes, *stops])
    return _weld(difference([handle, *bores, *pockets]))


def _handle_stop_heel(
    plan: B4BHandlePlan, cx: float
) -> trimesh.Trimesh:
    """A broad printed heel at one pivot, sized to land flat on its body stop.

    The cleared heel core spans the eye. Flat landing fingers reach the
    existing pad only over wall troughs, so neither a swept corner nor the
    adjacent wall crest can become an unintended stop.
    """
    tang = B4B_HANDLE_STOP_FACE / 2.0
    ang = math.radians(plan.stop_angle)
    # at stow the heel points nearly straight up; the deployed stop angle is
    # what brings its flat face round onto the body pad
    cy, cz = math.cos(ang), math.sin(ang)
    ny, nz = -math.sin(ang), math.cos(ang)
    base = plan.eye_radius - 0.6
    def profile(radial, tangent):
        return (plan.axis_y + radial * cy + tangent * ny,
                plan.axis_z + radial * cz + tangent * nz)

    # A rectangular heel's leading corner has radius hypot(radius, tang),
    # not radius: it grazed before its flat face reached the stop. Keep its
    # non-contact portion inside a cleared circle instead.
    end = _handle_end_radius(plan)
    core = Polygon([profile(base, -tang), profile(base, tang),
                    profile(end, tang), profile(end, -tang)])
    core = core.intersection(Point(plan.axis_y, plan.axis_z).buffer(
        end, quad_segs=48))
    heel = _extrude_yz_profile(core, plan.eye_band)
    heel.apply_translation((cx, 0.0, 0.0))
    pieces = [heel]
    # At the stop these fingers land on the upper half of the existing pad.
    # Their trailing-only face cannot swing past the pad plane on approach.
    # Only X runs backed by a wall trough may reach that plane.
    radial = plan.front_crest - plan.axis_y
    toe = Polygon([profile(base, 0.0), profile(radial, 0.0),
                   profile(radial, tang), profile(base, tang)])
    # A landing run ends 0.31 mm from the neighbouring wave crest; pull each
    # crest-side end back so the finger keeps the end clearance there too,
    # without thinning a run below the 0.4 mm it needs to land on the pad.
    relief = B4B_HANDLE_END_CLEARANCE - B4B_RUNNING_GAP - 0.01
    eye_lo, eye_hi = cx - plan.eye_band / 2.0, cx + plan.eye_band / 2.0
    for lo, hi in plan.heel_lands:
        if lo >= eye_lo and hi <= eye_hi:
            new_lo = lo + (relief if lo > eye_lo + 1e-6 else 0.0)
            new_hi = hi - (relief if hi < eye_hi - 1e-6 else 0.0)
            if new_hi - new_lo < 0.4:
                # keep a 0.4 mm landing centred in the run (a shorter run
                # is left as the plan resolved it)
                mid = (lo + hi) / 2.0
                new_lo, new_hi = (mid - 0.2, mid + 0.2) if hi - lo >= 0.4 else (lo, hi)
            lo, hi = new_lo, new_hi
            finger = _extrude_yz_profile(toe, hi - lo)
            finger.apply_translation(((lo + hi) / 2.0, 0.0, 0.0))
            pieces.append(finger)
    return union(pieces)


def _handle_body_parts(box: BoxSpec) -> list[trimesh.Trimesh]:
    """The two body pivot forks, their roots, the carry stops and the stow
    detents - all on the front wall, none of it on the lid."""
    plan = b4b_handle_plan(box)
    if plan is None:
        return []
    eff = b4b_effective_box(box)
    layout = b4b_layout(box)
    profile = plan.profile
    parts: list[trimesh.Trimesh] = []
    for cx in plan.centers_x:
        near_x, far_x = _handle_fork_positions(plan, cx)
        half = plan.root_width / 2.0 + 1.0
        cavity = _cavity_prism(box, cx - half, cx + half)
        height = plan.root_top_z - plan.root_bottom_z
        root_prof = _root_profile_yz(
            box,
            outward_sign=-1.0,
            face_y=plan.root_face_y,
            top_z=plan.root_top_z,
            height=height,
        )
        root = _extrude_yz_profile(root_prof, plan.root_width)
        root.apply_translation((cx, 0.0, 0.0))
        keeper = _root_taper_prism(
            centre_x=cx,
            root_width=plan.root_width,
            group_width=plan.fork_width,
            outward_sign=-1.0,
            crest_y=plan.front_crest,
            face_y=plan.root_face_y,
            z_lo=0.0,
            z_hi=plan.root_top_z,
        )
        solid = _intersection([root, keeper])
        for ex, thickness, terminal in (
            (near_x, plan.near_ear, False),
            (far_x, plan.far_lug, True),
        ):
            section = _filleted(
                _gusset(
                    root_y=_ear_wall_anchor_y(
                        layout, ex, thickness, -1.0, eff.wall_depth
                    ),
                    root_z=plan.root_bottom_z + 1.0,
                    top_z=plan.root_top_z,
                    axis_y=plan.axis_y,
                    axis_z=plan.axis_z,
                    radius=profile.pivot_radius,
                    outward_sign=-1.0,
                )
                .union(
                    _pivot_section(
                        profile, profile.pivot_radius, plan.axis_y, plan.axis_z
                    )
                )
                .union(root_prof),
                B4B_HW_FILLET,
            )
            solid = union([
                solid,
                _ear_solid(
                    section=section,
                    thickness=thickness,
                    x_centre=ex,
                    bore_r=profile.bore_radius(terminal),
                    axis_y=plan.axis_y,
                    axis_z=plan.axis_z,
                ),
            ])
        # the bail nests between the ears, so the root is two buttresses with a
        # running slot between them, never a slab across the whole wall contact
        relief = _relief_cutter(
            centre_x=cx,
            half_top=plan.eye_band / 2.0 + B4B_RUNNING_GAP,
            half_bottom=plan.band / 2.0 + B4B_HW_RELIEF_CLEARANCE,
            z_top=plan.root_top_z + 2.0,
            z_ramp_top=plan.axis_z,
            z_ramp_bottom=plan.axis_z - plan.taper_run,
            z_bottom=plan.root_bottom_z - 2.0,
            crest_y=plan.front_crest,
            face_y=plan.root_face_y,
            outward_sign=-1.0,
        )
        solid = difference([solid, cavity, relief])
        # The flat the deployed heel lands on.  At the stop angle the heel
        # has swung round to point straight at the wall, so the pad sits level
        # with the pivot axis - and it only fills the wave's troughs back to
        # the local crest, so it costs no projection at all.
        pad = trimesh.creation.box(
            extents=(plan.eye_band, 1.2, B4B_HANDLE_STOP_FACE)
        )
        pad.apply_translation((cx, plan.front_crest + 0.6, plan.axis_z))
        parts.append(union([solid, pad]))
    for cx in plan.detent_centers_x:
        # Radius comes from the ramp requirement, not from taste: the bump has
        # to rise its full height over at least this much run so the arm rides
        # on a slope shallower than 45 degrees instead of hitting a step.
        stand = plan.wall_clear + plan.detent_bump
        radius = max(2.0 * B4B_HANDLE_DETENT_RAMP, stand + B4B_HANDLE_DETENT_RAMP)
        bump = trimesh.creation.icosphere(subdivisions=2, radius=radius)
        bump.apply_scale((1.0, stand / radius, 1.0))
        bump.apply_translation((cx, plan.front_crest, plan.detent_z))
        parts.append(bump)
    return parts


# --------------------------------------------------------------------------- #
# validation
# --------------------------------------------------------------------------- #
def _lid_rear_relief_cutter(
    box: BoxSpec, plan: B4BHardwarePlan
) -> trimesh.Trimesh:
    """The 45-degree relief taken off the rear lid edge when the sweep needs it.

    Relief is always the first answer to an opening collision: shaving a
    fraction of a millimetre off an edge nobody sees is better than pushing the
    whole hinge further behind the case, which is what makes a slim box look
    like it is wearing a backpack.
    """
    eff = b4b_effective_box(box)
    layout = b4b_layout(box)
    underside_z = b4b_lid_underside_z_from_eff(eff)
    r = min(plan.lid_rear_relief, b4b_lid_skin_from_eff(eff) - 0.4)
    crest = layout.outer_half_y + WAVE_AMPLITUDE + 2.0
    profile = Polygon([
        (crest - r, underside_z - 0.01),
        (crest + 4.0, underside_z - 0.01),
        (crest + 4.0, underside_z + r),
        (crest, underside_z + r),
    ])
    case_x, _case_y = layout.case_size
    return _extrude_yz_profile(profile, case_x + 40.0)


def _sweep_intersection_cc(
    moving: trimesh.Trimesh,
    fixed: trimesh.Trimesh,
    axis_y: float,
    axis_z: float,
    angles_deg: tuple[float, ...],
) -> float:
    """Largest overlap volume (cc) between ``moving`` (rotated about the world-X
    line through ``(axis_y, axis_z)`` by each angle) and ``fixed``.

    A pose whose intersection cannot be computed is NOT treated as zero overlap
    (that would be fail-open): the whole check raises so the caller reports an
    unverifiable design rather than a false all-clear.
    """
    from organizer_engine import intersection_volume

    worst = 0.0
    for deg in angles_deg:
        m = moving.copy()
        m.apply_translation((0.0, -axis_y, -axis_z))
        m.apply_transform(
            trimesh.transformations.rotation_matrix(math.radians(deg), (1.0, 0.0, 0.0))
        )
        m.apply_translation((0.0, axis_y, axis_z))
        try:
            worst = max(worst, intersection_volume(m, fixed) / 1000.0)
        except Exception as exc:
            raise ValueError(
                f"could not verify the swept clearance at {deg:g} deg "
                f"({exc}); the Storage Box mechanics could not be validated"
            ) from exc
    return worst
